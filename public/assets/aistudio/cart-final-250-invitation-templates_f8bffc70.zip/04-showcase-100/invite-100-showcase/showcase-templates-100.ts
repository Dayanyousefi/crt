export type ShowcaseStage = {
  order: number;
  scene: string;
  title: string;
  description: string;
  interaction: 'tap-or-swipe' | 'tap' | 'drag-or-auto' | 'auto' | 'continue';
};

export type ShowcaseTemplate = {
  id: string;
  slug: string;
  name: { fa: string; en: string };
  category: string;
  style: { fa: string; en: string };
  visual_direction: string;
  palette: { base: string; accent: string };
  opening_mechanic: { fa: string; description: string };
  duration_seconds: number;
  stages: ShowcaseStage[];
  editable_fields: string[];
  responsive: boolean;
  reduced_motion_fallback: string;
  audio: { music_optional: boolean; sfx_optional: boolean; autoplay: boolean };
};

export const SHOWCASE_TEMPLATES_100: ShowcaseTemplate[] = [
  {
    "id": "showcase-001",
    "slug": "wedding-pearl-&-satin-01",
    "name": {
      "fa": "عروسی مروارید و ساتن 01",
      "en": "Pearl & Satin Wedding 01"
    },
    "category": "wedding",
    "style": {
      "fa": "مروارید و ساتن",
      "en": "Pearl & Satin"
    },
    "visual_direction": "مرواریدهای ریز، ساتن عاجی و نور نرم",
    "palette": {
      "base": "ivory",
      "accent": "champagne"
    },
    "opening_mechanic": {
      "fa": "دروازه دو لنگه",
      "description": "دو پنل مخملی با بازشدن متقارن؛ کارت از میان آن‌ها بیرون می‌آید"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "دروازه دو لنگه: دو پنل مخملی با بازشدن متقارن؛ کارت از میان آن‌ها بیرون می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-002",
    "slug": "wedding-velvet-night-02",
    "name": {
      "fa": "عروسی شب مخملی 02",
      "en": "Velvet Night Wedding 02"
    },
    "category": "wedding",
    "style": {
      "fa": "شب مخملی",
      "en": "Velvet Night"
    },
    "visual_direction": "مخمل سرمه‌ای، نقره برس‌خورده و نور نقطه‌ای",
    "palette": {
      "base": "midnight",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "پاکت مهرشده",
      "description": "مهر مومی ترک می‌خورد؛ لبه پاکت بالا می‌رود و کارت نمایان می‌شود"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پاکت مهرشده: مهر مومی ترک می‌خورد؛ لبه پاکت بالا می‌رود و کارت نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-003",
    "slug": "wedding-rose-garden-03",
    "name": {
      "fa": "عروسی باغ رز 03",
      "en": "Rose Garden Wedding 03"
    },
    "category": "wedding",
    "style": {
      "fa": "باغ رز",
      "en": "Rose Garden"
    },
    "visual_direction": "رز برجسته، کاغذ پنبه‌ای و روبان صورتی",
    "palette": {
      "base": "blush",
      "accent": "rose-gold"
    },
    "opening_mechanic": {
      "fa": "جعبه کشویی",
      "description": "روکش جعبه کنار می‌رود؛ کشو آرام بیرون می‌آید و کارت باز می‌شود"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "جعبه کشویی: روکش جعبه کنار می‌رود؛ کشو آرام بیرون می‌آید و کارت باز می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-004",
    "slug": "wedding-royal-emerald-04",
    "name": {
      "fa": "عروسی زمرد سلطنتی 04",
      "en": "Royal Emerald Wedding 04"
    },
    "category": "wedding",
    "style": {
      "fa": "زمرد سلطنتی",
      "en": "Royal Emerald"
    },
    "visual_direction": "زمرد تیره، طلاکوب ظریف و نقش اسلیمی",
    "palette": {
      "base": "emerald",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "آکاردئون کاغذی",
      "description": "نوار کاغذی چندلایه باز می‌شود و اطلاعات در پنل‌های پیوسته دیده می‌شود"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "آکاردئون کاغذی: نوار کاغذی چندلایه باز می‌شود و اطلاعات در پنل‌های پیوسته دیده می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-005",
    "slug": "wedding-stone-minimal-05",
    "name": {
      "fa": "عروسی مینیمال سنگی 05",
      "en": "Stone Minimal Wedding 05"
    },
    "category": "wedding",
    "style": {
      "fa": "مینیمال سنگی",
      "en": "Stone Minimal"
    },
    "visual_direction": "بافت سنگ روشن، تایپوگرافی خلوت و لبه‌های تمیز",
    "palette": {
      "base": "stone",
      "accent": "black"
    },
    "opening_mechanic": {
      "fa": "پرده حریر",
      "description": "پرده نیمه‌شفاف به دو طرف کنار می‌رود و کارت زیر آن ظاهر می‌شود"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پرده حریر: پرده نیمه‌شفاف به دو طرف کنار می‌رود و کارت زیر آن ظاهر می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-006",
    "slug": "wedding-sky-watercolor-06",
    "name": {
      "fa": "عروسی آبرنگ آسمانی 06",
      "en": "Sky Watercolor Wedding 06"
    },
    "category": "wedding",
    "style": {
      "fa": "آبرنگ آسمانی",
      "en": "Sky Watercolor"
    },
    "visual_direction": "آبرنگ محو، ابرهای لطیف و کاغذ نیمه‌شفاف",
    "palette": {
      "base": "sky",
      "accent": "pearl"
    },
    "opening_mechanic": {
      "fa": "کتاب عهد",
      "description": "جلد کتاب باز می‌شود؛ دو صفحه ورق می‌خورند و صفحه اصلی نمایان می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "کتاب عهد: جلد کتاب باز می‌شود؛ دو صفحه ورق می‌خورند و صفحه اصلی نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-007",
    "slug": "wedding-persian-termeh-07",
    "name": {
      "fa": "عروسی ترمه ایرانی 07",
      "en": "Persian Termeh Wedding 07"
    },
    "category": "wedding",
    "style": {
      "fa": "ترمه ایرانی",
      "en": "Persian Termeh"
    },
    "visual_direction": "ترمه الهام‌گرفته از بته‌جقه و قاب معماری ایرانی",
    "palette": {
      "base": "plum",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "گلبرگ‌های رز",
      "description": "گلبرگ‌ها از مرکز کنار می‌روند و کارت دایره‌ای از میان آن‌ها بالا می‌آید"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "گلبرگ‌های رز: گلبرگ‌ها از مرکز کنار می‌روند و کارت دایره‌ای از میان آن‌ها بالا می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-008",
    "slug": "wedding-botanical-08",
    "name": {
      "fa": "عروسی گیاه‌شناسی 08",
      "en": "Botanical Wedding 08"
    },
    "category": "wedding",
    "style": {
      "fa": "گیاه‌شناسی",
      "en": "Botanical"
    },
    "visual_direction": "برگ‌های برجسته، کاغذ بازیافتی لوکس و مس مات",
    "palette": {
      "base": "sage",
      "accent": "copper"
    },
    "opening_mechanic": {
      "fa": "روبان ضربدری",
      "description": "دو روبان از مرکز باز می‌شوند؛ درپوش تا می‌شود و کارت بیرون می‌آید"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "روبان ضربدری: دو روبان از مرکز باز می‌شوند؛ درپوش تا می‌شود و کارت بیرون می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-009",
    "slug": "wedding-art-deco-09",
    "name": {
      "fa": "عروسی آرت‌دکو 09",
      "en": "Art Deco Wedding 09"
    },
    "category": "wedding",
    "style": {
      "fa": "آرت‌دکو",
      "en": "Art Deco"
    },
    "visual_direction": "خطوط هندسی آرت‌دکو و فویل طلایی",
    "palette": {
      "base": "black",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "پنجره معماری",
      "description": "قاب پنجره‌ای دو لنگه باز می‌شود و منظره/کارت پشت آن آشکار می‌شود"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پنجره معماری: قاب پنجره‌ای دو لنگه باز می‌شود و منظره/کارت پشت آن آشکار می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-010",
    "slug": "wedding-ice-crystal-10",
    "name": {
      "fa": "عروسی کریستال یخی 10",
      "en": "Ice Crystal Wedding 10"
    },
    "category": "wedding",
    "style": {
      "fa": "کریستال یخی",
      "en": "Ice Crystal"
    },
    "visual_direction": "شفافیت کریستالی، لایه‌های شیشه‌ای و نقره سرد",
    "palette": {
      "base": "ice",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "مروارید شناور",
      "description": "مروارید مرکزی کنار می‌رود؛ حلقه نور باز می‌شود و کارت پدیدار می‌شود"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "مروارید شناور: مروارید مرکزی کنار می‌رود؛ حلقه نور باز می‌شود و کارت پدیدار می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-011",
    "slug": "engagement-pearl-&-satin-01",
    "name": {
      "fa": "نامزدی مروارید و ساتن 01",
      "en": "Pearl & Satin نامزدی 01"
    },
    "category": "engagement",
    "style": {
      "fa": "مروارید و ساتن",
      "en": "Pearl & Satin"
    },
    "visual_direction": "مرواریدهای ریز، ساتن عاجی و نور نرم",
    "palette": {
      "base": "ivory",
      "accent": "champagne"
    },
    "opening_mechanic": {
      "fa": "قفل قلبی",
      "description": "قفل قلبی باز می‌شود؛ دو نیمه قاب از هم جدا و متن نمایان می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "قفل قلبی: قفل قلبی باز می‌شود؛ دو نیمه قاب از هم جدا و متن نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-012",
    "slug": "engagement-velvet-night-02",
    "name": {
      "fa": "نامزدی شب مخملی 02",
      "en": "Velvet Night نامزدی 02"
    },
    "category": "engagement",
    "style": {
      "fa": "شب مخملی",
      "en": "Velvet Night"
    },
    "visual_direction": "مخمل سرمه‌ای، نقره برس‌خورده و نور نقطه‌ای",
    "palette": {
      "base": "midnight",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "پاکت مخملی",
      "description": "لبه پاکت با حرکت نرم باز می‌شود؛ کارت لایه‌لایه بیرون می‌آید"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پاکت مخملی: لبه پاکت با حرکت نرم باز می‌شود؛ کارت لایه‌لایه بیرون می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-013",
    "slug": "engagement-rose-garden-03",
    "name": {
      "fa": "نامزدی باغ رز 03",
      "en": "Rose Garden نامزدی 03"
    },
    "category": "engagement",
    "style": {
      "fa": "باغ رز",
      "en": "Rose Garden"
    },
    "visual_direction": "رز برجسته، کاغذ پنبه‌ای و روبان صورتی",
    "palette": {
      "base": "blush",
      "accent": "rose-gold"
    },
    "opening_mechanic": {
      "fa": "حلقه چرخان",
      "description": "حلقه روی محور می‌چرخد؛ پشت آن پنل دعوت آشکار می‌شود"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "حلقه چرخان: حلقه روی محور می‌چرخد؛ پشت آن پنل دعوت آشکار می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-014",
    "slug": "engagement-royal-emerald-04",
    "name": {
      "fa": "نامزدی زمرد سلطنتی 04",
      "en": "Royal Emerald نامزدی 04"
    },
    "category": "engagement",
    "style": {
      "fa": "زمرد سلطنتی",
      "en": "Royal Emerald"
    },
    "visual_direction": "زمرد تیره، طلاکوب ظریف و نقش اسلیمی",
    "palette": {
      "base": "emerald",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "جعبه انگشتر",
      "description": "در جعبه بالا می‌رود؛ نور داخلی روشن و کارت درون آن بالا می‌آید"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "جعبه انگشتر: در جعبه بالا می‌رود؛ نور داخلی روشن و کارت درون آن بالا می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-015",
    "slug": "engagement-stone-minimal-05",
    "name": {
      "fa": "نامزدی مینیمال سنگی 05",
      "en": "Stone Minimal نامزدی 05"
    },
    "category": "engagement",
    "style": {
      "fa": "مینیمال سنگی",
      "en": "Stone Minimal"
    },
    "visual_direction": "بافت سنگ روشن، تایپوگرافی خلوت و لبه‌های تمیز",
    "palette": {
      "base": "stone",
      "accent": "black"
    },
    "opening_mechanic": {
      "fa": "دو روبان",
      "description": "دو روبان متقاطع کشیده می‌شوند و پنل مرکزی آزاد می‌شود"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "دو روبان: دو روبان متقاطع کشیده می‌شوند و پنل مرکزی آزاد می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-016",
    "slug": "engagement-sky-watercolor-06",
    "name": {
      "fa": "نامزدی آبرنگ آسمانی 06",
      "en": "Sky Watercolor نامزدی 06"
    },
    "category": "engagement",
    "style": {
      "fa": "آبرنگ آسمانی",
      "en": "Sky Watercolor"
    },
    "visual_direction": "آبرنگ محو، ابرهای لطیف و کاغذ نیمه‌شفاف",
    "palette": {
      "base": "sky",
      "accent": "pearl"
    },
    "opening_mechanic": {
      "fa": "آینه بخارگرفته",
      "description": "بخار آینه محو می‌شود و نوشته‌ها از زیر آن ظاهر می‌شوند"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "آینه بخارگرفته: بخار آینه محو می‌شود و نوشته‌ها از زیر آن ظاهر می‌شوند",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-017",
    "slug": "engagement-persian-termeh-07",
    "name": {
      "fa": "نامزدی ترمه ایرانی 07",
      "en": "Persian Termeh نامزدی 07"
    },
    "category": "engagement",
    "style": {
      "fa": "ترمه ایرانی",
      "en": "Persian Termeh"
    },
    "visual_direction": "ترمه الهام‌گرفته از بته‌جقه و قاب معماری ایرانی",
    "palette": {
      "base": "plum",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "قلب تاشو",
      "description": "قلب کاغذی از وسط باز می‌شود و به کارت دوصفحه‌ای تبدیل می‌شود"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "قلب تاشو: قلب کاغذی از وسط باز می‌شود و به کارت دوصفحه‌ای تبدیل می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-018",
    "slug": "engagement-botanical-08",
    "name": {
      "fa": "نامزدی گیاه‌شناسی 08",
      "en": "Botanical نامزدی 08"
    },
    "category": "engagement",
    "style": {
      "fa": "گیاه‌شناسی",
      "en": "Botanical"
    },
    "visual_direction": "برگ‌های برجسته، کاغذ بازیافتی لوکس و مس مات",
    "palette": {
      "base": "sage",
      "accent": "copper"
    },
    "opening_mechanic": {
      "fa": "مهر برجسته",
      "description": "مهر برجسته جدا می‌شود و flap پاکت به‌آرامی می‌خوابد"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "مهر برجسته: مهر برجسته جدا می‌شود و flap پاکت به‌آرامی می‌خوابد",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-019",
    "slug": "engagement-art-deco-09",
    "name": {
      "fa": "نامزدی آرت‌دکو 09",
      "en": "Art Deco نامزدی 09"
    },
    "category": "engagement",
    "style": {
      "fa": "آرت‌دکو",
      "en": "Art Deco"
    },
    "visual_direction": "خطوط هندسی آرت‌دکو و فویل طلایی",
    "palette": {
      "base": "black",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "قاب گل",
      "description": "گل‌های کناری باز می‌شوند و قاب مرکزی به جلو می‌آید"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "قاب گل: گل‌های کناری باز می‌شوند و قاب مرکزی به جلو می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-020",
    "slug": "engagement-ice-crystal-10",
    "name": {
      "fa": "نامزدی کریستال یخی 10",
      "en": "Ice Crystal نامزدی 10"
    },
    "category": "engagement",
    "style": {
      "fa": "کریستال یخی",
      "en": "Ice Crystal"
    },
    "visual_direction": "شفافیت کریستالی، لایه‌های شیشه‌ای و نقره سرد",
    "palette": {
      "base": "ice",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "نوار سینمایی",
      "description": "فریم‌های باریک کنار می‌روند و کارت در قاب آخر ثابت می‌شود"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "نوار سینمایی: فریم‌های باریک کنار می‌روند و کارت در قاب آخر ثابت می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-021",
    "slug": "adult-birthday-pearl-&-satin-01",
    "name": {
      "fa": "تولد بزرگسال مروارید و ساتن 01",
      "en": "Pearl & Satin تولد بزرگسال 01"
    },
    "category": "adult-birthday",
    "style": {
      "fa": "مروارید و ساتن",
      "en": "Pearl & Satin"
    },
    "visual_direction": "مرواریدهای ریز، ساتن عاجی و نور نرم",
    "palette": {
      "base": "ivory",
      "accent": "champagne"
    },
    "opening_mechanic": {
      "fa": "کیک چندطبقه",
      "description": "لایه‌های کیک یکی‌یکی بالا می‌روند و کارت در طبقه آخر نمایان می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "کیک چندطبقه: لایه‌های کیک یکی‌یکی بالا می‌روند و کارت در طبقه آخر نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-022",
    "slug": "adult-birthday-velvet-night-02",
    "name": {
      "fa": "تولد بزرگسال شب مخملی 02",
      "en": "Velvet Night تولد بزرگسال 02"
    },
    "category": "adult-birthday",
    "style": {
      "fa": "شب مخملی",
      "en": "Velvet Night"
    },
    "visual_direction": "مخمل سرمه‌ای، نقره برس‌خورده و نور نقطه‌ای",
    "palette": {
      "base": "midnight",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "بادکنک‌های رها",
      "description": "بادکنک‌ها به بالا حرکت می‌کنند و کارت از پشت آن‌ها ظاهر می‌شود"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "بادکنک‌های رها: بادکنک‌ها به بالا حرکت می‌کنند و کارت از پشت آن‌ها ظاهر می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-023",
    "slug": "adult-birthday-rose-garden-03",
    "name": {
      "fa": "تولد بزرگسال باغ رز 03",
      "en": "Rose Garden تولد بزرگسال 03"
    },
    "category": "adult-birthday",
    "style": {
      "fa": "باغ رز",
      "en": "Rose Garden"
    },
    "visual_direction": "رز برجسته، کاغذ پنبه‌ای و روبان صورتی",
    "palette": {
      "base": "blush",
      "accent": "rose-gold"
    },
    "opening_mechanic": {
      "fa": "جعبه سورپرایز",
      "description": "درب جعبه باز می‌شود؛ کاغذ رنگی‌ها کنار می‌روند و کارت بالا می‌آید"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "جعبه سورپرایز: درب جعبه باز می‌شود؛ کاغذ رنگی‌ها کنار می‌روند و کارت بالا می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-024",
    "slug": "adult-birthday-royal-emerald-04",
    "name": {
      "fa": "تولد بزرگسال زمرد سلطنتی 04",
      "en": "Royal Emerald تولد بزرگسال 04"
    },
    "category": "adult-birthday",
    "style": {
      "fa": "زمرد سلطنتی",
      "en": "Royal Emerald"
    },
    "visual_direction": "زمرد تیره، طلاکوب ظریف و نقش اسلیمی",
    "palette": {
      "base": "emerald",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "صفحه وینیل",
      "description": "صفحه روی گرامافون می‌چرخد و با توقف، پنل دعوت از مرکز باز می‌شود"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "صفحه وینیل: صفحه روی گرامافون می‌چرخد و با توقف، پنل دعوت از مرکز باز می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-025",
    "slug": "adult-birthday-stone-minimal-05",
    "name": {
      "fa": "تولد بزرگسال مینیمال سنگی 05",
      "en": "Stone Minimal تولد بزرگسال 05"
    },
    "category": "adult-birthday",
    "style": {
      "fa": "مینیمال سنگی",
      "en": "Stone Minimal"
    },
    "visual_direction": "بافت سنگ روشن، تایپوگرافی خلوت و لبه‌های تمیز",
    "palette": {
      "base": "stone",
      "accent": "black"
    },
    "opening_mechanic": {
      "fa": "چراغ نئون",
      "description": "تابلو خاموش روشن می‌شود و خطوط نئون دور کارت شکل می‌گیرند"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "چراغ نئون: تابلو خاموش روشن می‌شود و خطوط نئون دور کارت شکل می‌گیرند",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-026",
    "slug": "adult-birthday-sky-watercolor-06",
    "name": {
      "fa": "تولد بزرگسال آبرنگ آسمانی 06",
      "en": "Sky Watercolor تولد بزرگسال 06"
    },
    "category": "adult-birthday",
    "style": {
      "fa": "آبرنگ آسمانی",
      "en": "Sky Watercolor"
    },
    "visual_direction": "آبرنگ محو، ابرهای لطیف و کاغذ نیمه‌شفاف",
    "palette": {
      "base": "sky",
      "accent": "pearl"
    },
    "opening_mechanic": {
      "fa": "پرده جشن",
      "description": "پرده از وسط باز می‌شود و کارت روی صحنه ظاهر می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پرده جشن: پرده از وسط باز می‌شود و کارت روی صحنه ظاهر می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-027",
    "slug": "adult-birthday-persian-termeh-07",
    "name": {
      "fa": "تولد بزرگسال ترمه ایرانی 07",
      "en": "Persian Termeh تولد بزرگسال 07"
    },
    "category": "adult-birthday",
    "style": {
      "fa": "ترمه ایرانی",
      "en": "Persian Termeh"
    },
    "visual_direction": "ترمه الهام‌گرفته از بته‌جقه و قاب معماری ایرانی",
    "palette": {
      "base": "plum",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "کارت پولاروید",
      "description": "عکس از بالا وارد قاب می‌شود و نوشته دعوت به‌تدریج ظاهر می‌شود"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "کارت پولاروید: عکس از بالا وارد قاب می‌شود و نوشته دعوت به‌تدریج ظاهر می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-028",
    "slug": "adult-birthday-botanical-08",
    "name": {
      "fa": "تولد بزرگسال گیاه‌شناسی 08",
      "en": "Botanical تولد بزرگسال 08"
    },
    "category": "adult-birthday",
    "style": {
      "fa": "گیاه‌شناسی",
      "en": "Botanical"
    },
    "visual_direction": "برگ‌های برجسته، کاغذ بازیافتی لوکس و مس مات",
    "palette": {
      "base": "sage",
      "accent": "copper"
    },
    "opening_mechanic": {
      "fa": "پاکت کنفتی",
      "description": "مهر باز می‌شود؛ کنفتی‌ها پخش می‌شوند و کارت از پاکت بیرون می‌آید"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پاکت کنفتی: مهر باز می‌شود؛ کنفتی‌ها پخش می‌شوند و کارت از پاکت بیرون می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-029",
    "slug": "adult-birthday-art-deco-09",
    "name": {
      "fa": "تولد بزرگسال آرت‌دکو 09",
      "en": "Art Deco تولد بزرگسال 09"
    },
    "category": "adult-birthday",
    "style": {
      "fa": "آرت‌دکو",
      "en": "Art Deco"
    },
    "visual_direction": "خطوط هندسی آرت‌دکو و فویل طلایی",
    "palette": {
      "base": "black",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "ساعت شمارش",
      "description": "عقربه‌ها یک دور می‌چرخند؛ صفحه ساعت کنار می‌رود و دعوت نمایان می‌شود"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "ساعت شمارش: عقربه‌ها یک دور می‌چرخند؛ صفحه ساعت کنار می‌رود و دعوت نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-030",
    "slug": "adult-birthday-ice-crystal-10",
    "name": {
      "fa": "تولد بزرگسال کریستال یخی 10",
      "en": "Ice Crystal تولد بزرگسال 10"
    },
    "category": "adult-birthday",
    "style": {
      "fa": "کریستال یخی",
      "en": "Ice Crystal"
    },
    "visual_direction": "شفافیت کریستالی، لایه‌های شیشه‌ای و نقره سرد",
    "palette": {
      "base": "ice",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "توپ دیسکو",
      "description": "توپ می‌چرخد؛ پرتوها کنار می‌روند و کارت در مرکز روشن می‌شود"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "توپ دیسکو: توپ می‌چرخد؛ پرتوها کنار می‌روند و کارت در مرکز روشن می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-031",
    "slug": "kids-birthday-pearl-&-satin-01",
    "name": {
      "fa": "تولد کودک مروارید و ساتن 01",
      "en": "Pearl & Satin تولد کودک 01"
    },
    "category": "kids-birthday",
    "style": {
      "fa": "مروارید و ساتن",
      "en": "Pearl & Satin"
    },
    "visual_direction": "مرواریدهای ریز، ساتن عاجی و نور نرم",
    "palette": {
      "base": "ivory",
      "accent": "champagne"
    },
    "opening_mechanic": {
      "fa": "قلعه قصه",
      "description": "دروازه قلعه باز می‌شود و کارت از مسیر پل بالا می‌آید"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "قلعه قصه: دروازه قلعه باز می‌شود و کارت از مسیر پل بالا می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-032",
    "slug": "kids-birthday-velvet-night-02",
    "name": {
      "fa": "تولد کودک شب مخملی 02",
      "en": "Velvet Night تولد کودک 02"
    },
    "category": "kids-birthday",
    "style": {
      "fa": "شب مخملی",
      "en": "Velvet Night"
    },
    "visual_direction": "مخمل سرمه‌ای، نقره برس‌خورده و نور نقطه‌ای",
    "palette": {
      "base": "midnight",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "صندوق گنج",
      "description": "قفل صندوق می‌پرد؛ در صندوق باز و نقشه دعوت نمایان می‌شود"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "صندوق گنج: قفل صندوق می‌پرد؛ در صندوق باز و نقشه دعوت نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-033",
    "slug": "kids-birthday-rose-garden-03",
    "name": {
      "fa": "تولد کودک باغ رز 03",
      "en": "Rose Garden تولد کودک 03"
    },
    "category": "kids-birthday",
    "style": {
      "fa": "باغ رز",
      "en": "Rose Garden"
    },
    "visual_direction": "رز برجسته، کاغذ پنبه‌ای و روبان صورتی",
    "palette": {
      "base": "blush",
      "accent": "rose-gold"
    },
    "opening_mechanic": {
      "fa": "ابر و رنگین‌کمان",
      "description": "ابرها کنار می‌روند و رنگین‌کمان به شکل قاب کارت کامل می‌شود"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "ابر و رنگین‌کمان: ابرها کنار می‌روند و رنگین‌کمان به شکل قاب کارت کامل می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-034",
    "slug": "kids-birthday-royal-emerald-04",
    "name": {
      "fa": "تولد کودک زمرد سلطنتی 04",
      "en": "Royal Emerald تولد کودک 04"
    },
    "category": "kids-birthday",
    "style": {
      "fa": "زمرد سلطنتی",
      "en": "Royal Emerald"
    },
    "visual_direction": "زمرد تیره، طلاکوب ظریف و نقش اسلیمی",
    "palette": {
      "base": "emerald",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "موشک فضایی",
      "description": "موشک از پایین اوج می‌گیرد؛ پنل آن باز و دعوت ظاهر می‌شود"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "موشک فضایی: موشک از پایین اوج می‌گیرد؛ پنل آن باز و دعوت ظاهر می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-035",
    "slug": "kids-birthday-stone-minimal-05",
    "name": {
      "fa": "تولد کودک مینیمال سنگی 05",
      "en": "Stone Minimal تولد کودک 05"
    },
    "category": "kids-birthday",
    "style": {
      "fa": "مینیمال سنگی",
      "en": "Stone Minimal"
    },
    "visual_direction": "بافت سنگ روشن، تایپوگرافی خلوت و لبه‌های تمیز",
    "palette": {
      "base": "stone",
      "accent": "black"
    },
    "opening_mechanic": {
      "fa": "کتاب قصه",
      "description": "صفحه اول ورق می‌خورد؛ تصویر داستانی کنار می‌رود و اطلاعات جشن می‌آید"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "کتاب قصه: صفحه اول ورق می‌خورد؛ تصویر داستانی کنار می‌رود و اطلاعات جشن می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-036",
    "slug": "kids-birthday-sky-watercolor-06",
    "name": {
      "fa": "تولد کودک آبرنگ آسمانی 06",
      "en": "Sky Watercolor تولد کودک 06"
    },
    "category": "kids-birthday",
    "style": {
      "fa": "آبرنگ آسمانی",
      "en": "Sky Watercolor"
    },
    "visual_direction": "آبرنگ محو، ابرهای لطیف و کاغذ نیمه‌شفاف",
    "palette": {
      "base": "sky",
      "accent": "pearl"
    },
    "opening_mechanic": {
      "fa": "قطار اسباب‌بازی",
      "description": "واگن‌ها وارد می‌شوند؛ واگن آخر حامل کارت است و در آن باز می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "قطار اسباب‌بازی: واگن‌ها وارد می‌شوند؛ واگن آخر حامل کارت است و در آن باز می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-037",
    "slug": "kids-birthday-persian-termeh-07",
    "name": {
      "fa": "تولد کودک ترمه ایرانی 07",
      "en": "Persian Termeh تولد کودک 07"
    },
    "category": "kids-birthday",
    "style": {
      "fa": "ترمه ایرانی",
      "en": "Persian Termeh"
    },
    "visual_direction": "ترمه الهام‌گرفته از بته‌جقه و قاب معماری ایرانی",
    "palette": {
      "base": "plum",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "بادبادک",
      "description": "بادبادک بالا می‌رود؛ نخ جمع می‌شود و کارت آویزان نمایان می‌شود"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "بادبادک: بادبادک بالا می‌رود؛ نخ جمع می‌شود و کارت آویزان نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-038",
    "slug": "kids-birthday-botanical-08",
    "name": {
      "fa": "تولد کودک گیاه‌شناسی 08",
      "en": "Botanical تولد کودک 08"
    },
    "category": "kids-birthday",
    "style": {
      "fa": "گیاه‌شناسی",
      "en": "Botanical"
    },
    "visual_direction": "برگ‌های برجسته، کاغذ بازیافتی لوکس و مس مات",
    "palette": {
      "base": "sage",
      "accent": "copper"
    },
    "opening_mechanic": {
      "fa": "حباب صابون",
      "description": "حباب‌ها یکی‌یکی می‌ترکند و کارت مرکزی واضح می‌شود"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "حباب صابون: حباب‌ها یکی‌یکی می‌ترکند و کارت مرکزی واضح می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-039",
    "slug": "kids-birthday-art-deco-09",
    "name": {
      "fa": "تولد کودک آرت‌دکو 09",
      "en": "Art Deco تولد کودک 09"
    },
    "category": "kids-birthday",
    "style": {
      "fa": "آرت‌دکو",
      "en": "Art Deco"
    },
    "visual_direction": "خطوط هندسی آرت‌دکو و فویل طلایی",
    "palette": {
      "base": "black",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "دایناسور تخم‌گذار",
      "description": "پوسته تخم می‌شکند؛ شخصیت بیرون می‌آید و کارت را باز می‌کند"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "دایناسور تخم‌گذار: پوسته تخم می‌شکند؛ شخصیت بیرون می‌آید و کارت را باز می‌کند",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-040",
    "slug": "kids-birthday-ice-crystal-10",
    "name": {
      "fa": "تولد کودک کریستال یخی 10",
      "en": "Ice Crystal تولد کودک 10"
    },
    "category": "kids-birthday",
    "style": {
      "fa": "کریستال یخی",
      "en": "Ice Crystal"
    },
    "visual_direction": "شفافیت کریستالی، لایه‌های شیشه‌ای و نقره سرد",
    "palette": {
      "base": "ice",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "چرخ‌وفلک",
      "description": "چرخ می‌چرخد و در توقف، کابین مرکزی به پنل دعوت تبدیل می‌شود"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "چرخ‌وفلک: چرخ می‌چرخد و در توقف، کابین مرکزی به پنل دعوت تبدیل می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-041",
    "slug": "baby-shower-pearl-&-satin-01",
    "name": {
      "fa": "جشن نوزاد مروارید و ساتن 01",
      "en": "Pearl & Satin جشن نوزاد 01"
    },
    "category": "baby-shower",
    "style": {
      "fa": "مروارید و ساتن",
      "en": "Pearl & Satin"
    },
    "visual_direction": "مرواریدهای ریز، ساتن عاجی و نور نرم",
    "palette": {
      "base": "ivory",
      "accent": "champagne"
    },
    "opening_mechanic": {
      "fa": "دروازه کاغذ پوستی",
      "description": "دو لایه vellum کنار می‌روند و کارت زیرین دیده می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "دروازه کاغذ پوستی: دو لایه vellum کنار می‌روند و کارت زیرین دیده می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-042",
    "slug": "baby-shower-velvet-night-02",
    "name": {
      "fa": "جشن نوزاد شب مخملی 02",
      "en": "Velvet Night جشن نوزاد 02"
    },
    "category": "baby-shower",
    "style": {
      "fa": "شب مخملی",
      "en": "Velvet Night"
    },
    "visual_direction": "مخمل سرمه‌ای، نقره برس‌خورده و نور نقطه‌ای",
    "palette": {
      "base": "midnight",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "روبان پاستلی",
      "description": "گره روبان باز می‌شود؛ دو لبه کاغذ به طرفین تا می‌خورند"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "روبان پاستلی: گره روبان باز می‌شود؛ دو لبه کاغذ به طرفین تا می‌خورند",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-043",
    "slug": "baby-shower-rose-garden-03",
    "name": {
      "fa": "جشن نوزاد باغ رز 03",
      "en": "Rose Garden جشن نوزاد 03"
    },
    "category": "baby-shower",
    "style": {
      "fa": "باغ رز",
      "en": "Rose Garden"
    },
    "visual_direction": "رز برجسته، کاغذ پنبه‌ای و روبان صورتی",
    "palette": {
      "base": "blush",
      "accent": "rose-gold"
    },
    "opening_mechanic": {
      "fa": "گهواره",
      "description": "سایه‌بان گهواره بالا می‌رود و کارت از داخل آن ظاهر می‌شود"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "گهواره: سایه‌بان گهواره بالا می‌رود و کارت از داخل آن ظاهر می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-044",
    "slug": "baby-shower-royal-emerald-04",
    "name": {
      "fa": "جشن نوزاد زمرد سلطنتی 04",
      "en": "Royal Emerald جشن نوزاد 04"
    },
    "category": "baby-shower",
    "style": {
      "fa": "زمرد سلطنتی",
      "en": "Royal Emerald"
    },
    "visual_direction": "زمرد تیره، طلاکوب ظریف و نقش اسلیمی",
    "palette": {
      "base": "emerald",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "ابرهای نرم",
      "description": "ابرها با حرکت آهسته کنار می‌روند و ستاره‌ها قاب دعوت را می‌سازند"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "ابرهای نرم: ابرها با حرکت آهسته کنار می‌روند و ستاره‌ها قاب دعوت را می‌سازند",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-045",
    "slug": "baby-shower-stone-minimal-05",
    "name": {
      "fa": "جشن نوزاد مینیمال سنگی 05",
      "en": "Stone Minimal جشن نوزاد 05"
    },
    "category": "baby-shower",
    "style": {
      "fa": "مینیمال سنگی",
      "en": "Stone Minimal"
    },
    "visual_direction": "بافت سنگ روشن، تایپوگرافی خلوت و لبه‌های تمیز",
    "palette": {
      "base": "stone",
      "accent": "black"
    },
    "opening_mechanic": {
      "fa": "جعبه هدیه کوچک",
      "description": "در جعبه باز می‌شود و کارت به‌آرامی بالا می‌آید"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "جعبه هدیه کوچک: در جعبه باز می‌شود و کارت به‌آرامی بالا می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-046",
    "slug": "baby-shower-sky-watercolor-06",
    "name": {
      "fa": "جشن نوزاد آبرنگ آسمانی 06",
      "en": "Sky Watercolor جشن نوزاد 06"
    },
    "category": "baby-shower",
    "style": {
      "fa": "آبرنگ آسمانی",
      "en": "Sky Watercolor"
    },
    "visual_direction": "آبرنگ محو، ابرهای لطیف و کاغذ نیمه‌شفاف",
    "palette": {
      "base": "sky",
      "accent": "pearl"
    },
    "opening_mechanic": {
      "fa": "گل خشک",
      "description": "شاخه‌های خشک به اطراف می‌چرخند و کارت در مرکز آشکار می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "گل خشک: شاخه‌های خشک به اطراف می‌چرخند و کارت در مرکز آشکار می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-047",
    "slug": "baby-shower-persian-termeh-07",
    "name": {
      "fa": "جشن نوزاد ترمه ایرانی 07",
      "en": "Persian Termeh جشن نوزاد 07"
    },
    "category": "baby-shower",
    "style": {
      "fa": "ترمه ایرانی",
      "en": "Persian Termeh"
    },
    "visual_direction": "ترمه الهام‌گرفته از بته‌جقه و قاب معماری ایرانی",
    "palette": {
      "base": "plum",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "ماه و ستاره",
      "description": "ماه هلال می‌چرخد؛ ستاره‌ها مسیر بازشدن پنل را روشن می‌کنند"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "ماه و ستاره: ماه هلال می‌چرخد؛ ستاره‌ها مسیر بازشدن پنل را روشن می‌کنند",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-048",
    "slug": "baby-shower-botanical-08",
    "name": {
      "fa": "جشن نوزاد گیاه‌شناسی 08",
      "en": "Botanical جشن نوزاد 08"
    },
    "category": "baby-shower",
    "style": {
      "fa": "گیاه‌شناسی",
      "en": "Botanical"
    },
    "visual_direction": "برگ‌های برجسته، کاغذ بازیافتی لوکس و مس مات",
    "palette": {
      "base": "sage",
      "accent": "copper"
    },
    "opening_mechanic": {
      "fa": "پاکت لایه‌ای",
      "description": "سه لایه پاکت با ترتیب مشخص باز می‌شوند و کارت نهایی بیرون می‌آید"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پاکت لایه‌ای: سه لایه پاکت با ترتیب مشخص باز می‌شوند و کارت نهایی بیرون می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-049",
    "slug": "baby-shower-art-deco-09",
    "name": {
      "fa": "جشن نوزاد آرت‌دکو 09",
      "en": "Art Deco جشن نوزاد 09"
    },
    "category": "baby-shower",
    "style": {
      "fa": "آرت‌دکو",
      "en": "Art Deco"
    },
    "visual_direction": "خطوط هندسی آرت‌دکو و فویل طلایی",
    "palette": {
      "base": "black",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "آلبوم خاطره",
      "description": "صفحات آلبوم ورق می‌خورند و صفحه آخر اطلاعات جشن را نشان می‌دهد"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "آلبوم خاطره: صفحات آلبوم ورق می‌خورند و صفحه آخر اطلاعات جشن را نشان می‌دهد",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-050",
    "slug": "baby-shower-ice-crystal-10",
    "name": {
      "fa": "جشن نوزاد کریستال یخی 10",
      "en": "Ice Crystal جشن نوزاد 10"
    },
    "category": "baby-shower",
    "style": {
      "fa": "کریستال یخی",
      "en": "Ice Crystal"
    },
    "visual_direction": "شفافیت کریستالی، لایه‌های شیشه‌ای و نقره سرد",
    "palette": {
      "base": "ice",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "پر کاغذی",
      "description": "پرها کنار می‌روند و پنل دعوت از میان آن‌ها بالا می‌آید"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پر کاغذی: پرها کنار می‌روند و پنل دعوت از میان آن‌ها بالا می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-051",
    "slug": "graduation-pearl-&-satin-01",
    "name": {
      "fa": "فارغ‌التحصیلی مروارید و ساتن 01",
      "en": "Pearl & Satin فارغ‌التحصیلی 01"
    },
    "category": "graduation",
    "style": {
      "fa": "مروارید و ساتن",
      "en": "Pearl & Satin"
    },
    "visual_direction": "مرواریدهای ریز، ساتن عاجی و نور نرم",
    "palette": {
      "base": "ivory",
      "accent": "champagne"
    },
    "opening_mechanic": {
      "fa": "جلد دیپلم",
      "description": "روبان دیپلم باز می‌شود؛ طومار باز و دعوت نمایان می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "جلد دیپلم: روبان دیپلم باز می‌شود؛ طومار باز و دعوت نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-052",
    "slug": "graduation-velvet-night-02",
    "name": {
      "fa": "فارغ‌التحصیلی شب مخملی 02",
      "en": "Velvet Night فارغ‌التحصیلی 02"
    },
    "category": "graduation",
    "style": {
      "fa": "شب مخملی",
      "en": "Velvet Night"
    },
    "visual_direction": "مخمل سرمه‌ای، نقره برس‌خورده و نور نقطه‌ای",
    "palette": {
      "base": "midnight",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "کلاه فارغ‌التحصیلی",
      "description": "کلاه می‌چرخد؛ منگوله کنار می‌رود و کارت از زیر آن بیرون می‌آید"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "کلاه فارغ‌التحصیلی: کلاه می‌چرخد؛ منگوله کنار می‌رود و کارت از زیر آن بیرون می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-053",
    "slug": "graduation-rose-garden-03",
    "name": {
      "fa": "فارغ‌التحصیلی باغ رز 03",
      "en": "Rose Garden فارغ‌التحصیلی 03"
    },
    "category": "graduation",
    "style": {
      "fa": "باغ رز",
      "en": "Rose Garden"
    },
    "visual_direction": "رز برجسته، کاغذ پنبه‌ای و روبان صورتی",
    "palette": {
      "base": "blush",
      "accent": "rose-gold"
    },
    "opening_mechanic": {
      "fa": "کتاب دانشگاه",
      "description": "کتاب بسته باز می‌شود؛ صفحات ورق می‌خورند و کارت روی صفحه آخر قرار می‌گیرد"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "کتاب دانشگاه: کتاب بسته باز می‌شود؛ صفحات ورق می‌خورند و کارت روی صفحه آخر قرار می‌گیرد",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-054",
    "slug": "graduation-royal-emerald-04",
    "name": {
      "fa": "فارغ‌التحصیلی زمرد سلطنتی 04",
      "en": "Royal Emerald فارغ‌التحصیلی 04"
    },
    "category": "graduation",
    "style": {
      "fa": "زمرد سلطنتی",
      "en": "Royal Emerald"
    },
    "visual_direction": "زمرد تیره، طلاکوب ظریف و نقش اسلیمی",
    "palette": {
      "base": "emerald",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "مهر برجسته دانشگاه",
      "description": "مهر شکسته می‌شود و گواهی دعوت از زیر آن بیرون می‌آید"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "مهر برجسته دانشگاه: مهر شکسته می‌شود و گواهی دعوت از زیر آن بیرون می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-055",
    "slug": "graduation-stone-minimal-05",
    "name": {
      "fa": "فارغ‌التحصیلی مینیمال سنگی 05",
      "en": "Stone Minimal فارغ‌التحصیلی 05"
    },
    "category": "graduation",
    "style": {
      "fa": "مینیمال سنگی",
      "en": "Stone Minimal"
    },
    "visual_direction": "بافت سنگ روشن، تایپوگرافی خلوت و لبه‌های تمیز",
    "palette": {
      "base": "stone",
      "accent": "black"
    },
    "opening_mechanic": {
      "fa": "پله‌های موفقیت",
      "description": "پله‌ها یکی‌یکی روشن می‌شوند و در انتها پنل دعوت بالا می‌آید"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پله‌های موفقیت: پله‌ها یکی‌یکی روشن می‌شوند و در انتها پنل دعوت بالا می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-056",
    "slug": "graduation-sky-watercolor-06",
    "name": {
      "fa": "فارغ‌التحصیلی آبرنگ آسمانی 06",
      "en": "Sky Watercolor فارغ‌التحصیلی 06"
    },
    "category": "graduation",
    "style": {
      "fa": "آبرنگ آسمانی",
      "en": "Sky Watercolor"
    },
    "visual_direction": "آبرنگ محو، ابرهای لطیف و کاغذ نیمه‌شفاف",
    "palette": {
      "base": "sky",
      "accent": "pearl"
    },
    "opening_mechanic": {
      "fa": "قاب مدال",
      "description": "مدال می‌چرخد و قاب پشتی باز می‌شود تا اطلاعات جشن نمایان شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "قاب مدال: مدال می‌چرخد و قاب پشتی باز می‌شود تا اطلاعات جشن نمایان شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-057",
    "slug": "graduation-persian-termeh-07",
    "name": {
      "fa": "فارغ‌التحصیلی ترمه ایرانی 07",
      "en": "Persian Termeh فارغ‌التحصیلی 07"
    },
    "category": "graduation",
    "style": {
      "fa": "ترمه ایرانی",
      "en": "Persian Termeh"
    },
    "visual_direction": "ترمه الهام‌گرفته از بته‌جقه و قاب معماری ایرانی",
    "palette": {
      "base": "plum",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "طومار مدرن",
      "description": "دو میله از هم دور می‌شوند و طومار افقی باز می‌شود"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "طومار مدرن: دو میله از هم دور می‌شوند و طومار افقی باز می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-058",
    "slug": "graduation-botanical-08",
    "name": {
      "fa": "فارغ‌التحصیلی گیاه‌شناسی 08",
      "en": "Botanical فارغ‌التحصیلی 08"
    },
    "category": "graduation",
    "style": {
      "fa": "گیاه‌شناسی",
      "en": "Botanical"
    },
    "visual_direction": "برگ‌های برجسته، کاغذ بازیافتی لوکس و مس مات",
    "palette": {
      "base": "sage",
      "accent": "copper"
    },
    "opening_mechanic": {
      "fa": "جعبه یادگاری",
      "description": "جعبه باز می‌شود و عکس/کارت از داخل آن بیرون می‌آید"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "جعبه یادگاری: جعبه باز می‌شود و عکس/کارت از داخل آن بیرون می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-059",
    "slug": "graduation-art-deco-09",
    "name": {
      "fa": "فارغ‌التحصیلی آرت‌دکو 09",
      "en": "Art Deco فارغ‌التحصیلی 09"
    },
    "category": "graduation",
    "style": {
      "fa": "آرت‌دکو",
      "en": "Art Deco"
    },
    "visual_direction": "خطوط هندسی آرت‌دکو و فویل طلایی",
    "palette": {
      "base": "black",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "نور صحنه",
      "description": "نورافکن‌ها روشن می‌شوند و پرده کناری کنار می‌رود"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "نور صحنه: نورافکن‌ها روشن می‌شوند و پرده کناری کنار می‌رود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-060",
    "slug": "graduation-ice-crystal-10",
    "name": {
      "fa": "فارغ‌التحصیلی کریستال یخی 10",
      "en": "Ice Crystal فارغ‌التحصیلی 10"
    },
    "category": "graduation",
    "style": {
      "fa": "کریستال یخی",
      "en": "Ice Crystal"
    },
    "visual_direction": "شفافیت کریستالی، لایه‌های شیشه‌ای و نقره سرد",
    "palette": {
      "base": "ice",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "پرواز کاغذها",
      "description": "کاغذهای یادداشت به اطراف می‌روند و کارت اصلی در مرکز می‌ماند"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پرواز کاغذها: کاغذهای یادداشت به اطراف می‌روند و کارت اصلی در مرکز می‌ماند",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-061",
    "slug": "gala-pearl-&-satin-01",
    "name": {
      "fa": "مراسم رسمی و گالا مروارید و ساتن 01",
      "en": "Pearl & Satin مراسم رسمی و گالا 01"
    },
    "category": "gala",
    "style": {
      "fa": "مروارید و ساتن",
      "en": "Pearl & Satin"
    },
    "visual_direction": "مرواریدهای ریز، ساتن عاجی و نور نرم",
    "palette": {
      "base": "ivory",
      "accent": "champagne"
    },
    "opening_mechanic": {
      "fa": "پرده اپرا",
      "description": "پرده سنگین به دو طرف جمع می‌شود و کارت روی صحنه ظاهر می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پرده اپرا: پرده سنگین به دو طرف جمع می‌شود و کارت روی صحنه ظاهر می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-062",
    "slug": "gala-velvet-night-02",
    "name": {
      "fa": "مراسم رسمی و گالا شب مخملی 02",
      "en": "Velvet Night مراسم رسمی و گالا 02"
    },
    "category": "gala",
    "style": {
      "fa": "شب مخملی",
      "en": "Velvet Night"
    },
    "visual_direction": "مخمل سرمه‌ای، نقره برس‌خورده و نور نقطه‌ای",
    "palette": {
      "base": "midnight",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "جعبه جواهر",
      "description": "قفل جعبه آزاد می‌شود؛ در مخملی بالا می‌رود و کارت می‌درخشد"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "جعبه جواهر: قفل جعبه آزاد می‌شود؛ در مخملی بالا می‌رود و کارت می‌درخشد",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-063",
    "slug": "gala-rose-garden-03",
    "name": {
      "fa": "مراسم رسمی و گالا باغ رز 03",
      "en": "Rose Garden مراسم رسمی و گالا 03"
    },
    "category": "gala",
    "style": {
      "fa": "باغ رز",
      "en": "Rose Garden"
    },
    "visual_direction": "رز برجسته، کاغذ پنبه‌ای و روبان صورتی",
    "palette": {
      "base": "blush",
      "accent": "rose-gold"
    },
    "opening_mechanic": {
      "fa": "پاکت مشکی",
      "description": "مهر فلزی می‌چرخد؛ flap باز و کارت طلایی بیرون می‌آید"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پاکت مشکی: مهر فلزی می‌چرخد؛ flap باز و کارت طلایی بیرون می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-064",
    "slug": "gala-royal-emerald-04",
    "name": {
      "fa": "مراسم رسمی و گالا زمرد سلطنتی 04",
      "en": "Royal Emerald مراسم رسمی و گالا 04"
    },
    "category": "gala",
    "style": {
      "fa": "زمرد سلطنتی",
      "en": "Royal Emerald"
    },
    "visual_direction": "زمرد تیره، طلاکوب ظریف و نقش اسلیمی",
    "palette": {
      "base": "emerald",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "کارت لیزری",
      "description": "خطوط نوری قاب را اسکن می‌کنند و پنل مرکزی باز می‌شود"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "کارت لیزری: خطوط نوری قاب را اسکن می‌کنند و پنل مرکزی باز می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-065",
    "slug": "gala-stone-minimal-05",
    "name": {
      "fa": "مراسم رسمی و گالا مینیمال سنگی 05",
      "en": "Stone Minimal مراسم رسمی و گالا 05"
    },
    "category": "gala",
    "style": {
      "fa": "مینیمال سنگی",
      "en": "Stone Minimal"
    },
    "visual_direction": "بافت سنگ روشن، تایپوگرافی خلوت و لبه‌های تمیز",
    "palette": {
      "base": "stone",
      "accent": "black"
    },
    "opening_mechanic": {
      "fa": "درهای آسانسور",
      "description": "دو در از مرکز باز می‌شوند و کارت داخل کابین نمایان می‌شود"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "درهای آسانسور: دو در از مرکز باز می‌شوند و کارت داخل کابین نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-066",
    "slug": "gala-sky-watercolor-06",
    "name": {
      "fa": "مراسم رسمی و گالا آبرنگ آسمانی 06",
      "en": "Sky Watercolor مراسم رسمی و گالا 06"
    },
    "category": "gala",
    "style": {
      "fa": "آبرنگ آسمانی",
      "en": "Sky Watercolor"
    },
    "visual_direction": "آبرنگ محو، ابرهای لطیف و کاغذ نیمه‌شفاف",
    "palette": {
      "base": "sky",
      "accent": "pearl"
    },
    "opening_mechanic": {
      "fa": "منوی شام",
      "description": "جلد منو باز می‌شود؛ صفحات ورق می‌خورند و دعوت روی صفحه آخر می‌آید"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "منوی شام: جلد منو باز می‌شود؛ صفحات ورق می‌خورند و دعوت روی صفحه آخر می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-067",
    "slug": "gala-persian-termeh-07",
    "name": {
      "fa": "مراسم رسمی و گالا ترمه ایرانی 07",
      "en": "Persian Termeh مراسم رسمی و گالا 07"
    },
    "category": "gala",
    "style": {
      "fa": "ترمه ایرانی",
      "en": "Persian Termeh"
    },
    "visual_direction": "ترمه الهام‌گرفته از بته‌جقه و قاب معماری ایرانی",
    "palette": {
      "base": "plum",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "جام کریستال",
      "description": "جام می‌چرخد و انعکاس نور به قاب کارت تبدیل می‌شود"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "جام کریستال: جام می‌چرخد و انعکاس نور به قاب کارت تبدیل می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-068",
    "slug": "gala-botanical-08",
    "name": {
      "fa": "مراسم رسمی و گالا گیاه‌شناسی 08",
      "en": "Botanical مراسم رسمی و گالا 08"
    },
    "category": "gala",
    "style": {
      "fa": "گیاه‌شناسی",
      "en": "Botanical"
    },
    "visual_direction": "برگ‌های برجسته، کاغذ بازیافتی لوکس و مس مات",
    "palette": {
      "base": "sage",
      "accent": "copper"
    },
    "opening_mechanic": {
      "fa": "نوار مخملی",
      "description": "نوار از روی جعبه سر می‌خورد و پنل مرکزی آزاد می‌شود"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "نوار مخملی: نوار از روی جعبه سر می‌خورد و پنل مرکزی آزاد می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-069",
    "slug": "gala-art-deco-09",
    "name": {
      "fa": "مراسم رسمی و گالا آرت‌دکو 09",
      "en": "Art Deco مراسم رسمی و گالا 09"
    },
    "category": "gala",
    "style": {
      "fa": "آرت‌دکو",
      "en": "Art Deco"
    },
    "visual_direction": "خطوط هندسی آرت‌دکو و فویل طلایی",
    "palette": {
      "base": "black",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "قاب آرت‌دکو",
      "description": "چهار گوشه قاب باز می‌شوند و پنل طلایی از مرکز بیرون می‌آید"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "قاب آرت‌دکو: چهار گوشه قاب باز می‌شوند و پنل طلایی از مرکز بیرون می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-070",
    "slug": "gala-ice-crystal-10",
    "name": {
      "fa": "مراسم رسمی و گالا کریستال یخی 10",
      "en": "Ice Crystal مراسم رسمی و گالا 10"
    },
    "category": "gala",
    "style": {
      "fa": "کریستال یخی",
      "en": "Ice Crystal"
    },
    "visual_direction": "شفافیت کریستالی، لایه‌های شیشه‌ای و نقره سرد",
    "palette": {
      "base": "ice",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "مهر مومی دوتایی",
      "description": "دو مهر به طرفین می‌روند و پاکت مرکزی باز می‌شود"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "مهر مومی دوتایی: دو مهر به طرفین می‌روند و پاکت مرکزی باز می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-071",
    "slug": "traditional-pearl-&-satin-01",
    "name": {
      "fa": "مراسم مذهبی/سنتی مروارید و ساتن 01",
      "en": "Pearl & Satin مراسم مذهبی/سنتی 01"
    },
    "category": "traditional",
    "style": {
      "fa": "مروارید و ساتن",
      "en": "Pearl & Satin"
    },
    "visual_direction": "مرواریدهای ریز، ساتن عاجی و نور نرم",
    "palette": {
      "base": "ivory",
      "accent": "champagne"
    },
    "opening_mechanic": {
      "fa": "طاق ایرانی",
      "description": "دو لنگه با نقش اسلیمی باز می‌شوند و کارت از زیر طاق نمایان می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "طاق ایرانی: دو لنگه با نقش اسلیمی باز می‌شوند و کارت از زیر طاق نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-072",
    "slug": "traditional-velvet-night-02",
    "name": {
      "fa": "مراسم مذهبی/سنتی شب مخملی 02",
      "en": "Velvet Night مراسم مذهبی/سنتی 02"
    },
    "category": "traditional",
    "style": {
      "fa": "شب مخملی",
      "en": "Velvet Night"
    },
    "visual_direction": "مخمل سرمه‌ای، نقره برس‌خورده و نور نقطه‌ای",
    "palette": {
      "base": "midnight",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "طومار خوشنویسی",
      "description": "مهر باز می‌شود و طومار با حرکت آرام گشوده می‌شود"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "طومار خوشنویسی: مهر باز می‌شود و طومار با حرکت آرام گشوده می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-073",
    "slug": "traditional-rose-garden-03",
    "name": {
      "fa": "مراسم مذهبی/سنتی باغ رز 03",
      "en": "Rose Garden مراسم مذهبی/سنتی 03"
    },
    "category": "traditional",
    "style": {
      "fa": "باغ رز",
      "en": "Rose Garden"
    },
    "visual_direction": "رز برجسته، کاغذ پنبه‌ای و روبان صورتی",
    "palette": {
      "base": "blush",
      "accent": "rose-gold"
    },
    "opening_mechanic": {
      "fa": "چراغ فانوس",
      "description": "فانوس روشن می‌شود؛ پنل‌های آن باز و دعوت ظاهر می‌شود"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "چراغ فانوس: فانوس روشن می‌شود؛ پنل‌های آن باز و دعوت ظاهر می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-074",
    "slug": "traditional-royal-emerald-04",
    "name": {
      "fa": "مراسم مذهبی/سنتی زمرد سلطنتی 04",
      "en": "Royal Emerald مراسم مذهبی/سنتی 04"
    },
    "category": "traditional",
    "style": {
      "fa": "زمرد سلطنتی",
      "en": "Royal Emerald"
    },
    "visual_direction": "زمرد تیره، طلاکوب ظریف و نقش اسلیمی",
    "palette": {
      "base": "emerald",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "ترمه تاشو",
      "description": "پارچه ترمه به شکل چهار لت کنار می‌رود و کارت مرکزی آشکار می‌شود"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "ترمه تاشو: پارچه ترمه به شکل چهار لت کنار می‌رود و کارت مرکزی آشکار می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-075",
    "slug": "traditional-stone-minimal-05",
    "name": {
      "fa": "مراسم مذهبی/سنتی مینیمال سنگی 05",
      "en": "Stone Minimal مراسم مذهبی/سنتی 05"
    },
    "category": "traditional",
    "style": {
      "fa": "مینیمال سنگی",
      "en": "Stone Minimal"
    },
    "visual_direction": "بافت سنگ روشن، تایپوگرافی خلوت و لبه‌های تمیز",
    "palette": {
      "base": "stone",
      "accent": "black"
    },
    "opening_mechanic": {
      "fa": "گنبد و هلال",
      "description": "هلال بالا می‌رود و پنل دعوت زیر گنبد نمایان می‌شود"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "گنبد و هلال: هلال بالا می‌رود و پنل دعوت زیر گنبد نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-076",
    "slug": "traditional-sky-watercolor-06",
    "name": {
      "fa": "مراسم مذهبی/سنتی آبرنگ آسمانی 06",
      "en": "Sky Watercolor مراسم مذهبی/سنتی 06"
    },
    "category": "traditional",
    "style": {
      "fa": "آبرنگ آسمانی",
      "en": "Sky Watercolor"
    },
    "visual_direction": "آبرنگ محو، ابرهای لطیف و کاغذ نیمه‌شفاف",
    "palette": {
      "base": "sky",
      "accent": "pearl"
    },
    "opening_mechanic": {
      "fa": "جعبه خاتم",
      "description": "در خاتم‌کاری‌شده باز می‌شود و کارت از داخل بیرون می‌آید"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "جعبه خاتم: در خاتم‌کاری‌شده باز می‌شود و کارت از داخل بیرون می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-077",
    "slug": "traditional-persian-termeh-07",
    "name": {
      "fa": "مراسم مذهبی/سنتی ترمه ایرانی 07",
      "en": "Persian Termeh مراسم مذهبی/سنتی 07"
    },
    "category": "traditional",
    "style": {
      "fa": "ترمه ایرانی",
      "en": "Persian Termeh"
    },
    "visual_direction": "ترمه الهام‌گرفته از بته‌جقه و قاب معماری ایرانی",
    "palette": {
      "base": "plum",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "قاب مشبک",
      "description": "پنجره مشبک کنار می‌رود و متن از پشت آن ظاهر می‌شود"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "قاب مشبک: پنجره مشبک کنار می‌رود و متن از پشت آن ظاهر می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-078",
    "slug": "traditional-botanical-08",
    "name": {
      "fa": "مراسم مذهبی/سنتی گیاه‌شناسی 08",
      "en": "Botanical مراسم مذهبی/سنتی 08"
    },
    "category": "traditional",
    "style": {
      "fa": "گیاه‌شناسی",
      "en": "Botanical"
    },
    "visual_direction": "برگ‌های برجسته، کاغذ بازیافتی لوکس و مس مات",
    "palette": {
      "base": "sage",
      "accent": "copper"
    },
    "opening_mechanic": {
      "fa": "مهر لاکی",
      "description": "مهر لاکی می‌شکند و دو لایه کاغذ باز می‌شوند"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "مهر لاکی: مهر لاکی می‌شکند و دو لایه کاغذ باز می‌شوند",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-079",
    "slug": "traditional-art-deco-09",
    "name": {
      "fa": "مراسم مذهبی/سنتی آرت‌دکو 09",
      "en": "Art Deco مراسم مذهبی/سنتی 09"
    },
    "category": "traditional",
    "style": {
      "fa": "آرت‌دکو",
      "en": "Art Deco"
    },
    "visual_direction": "خطوط هندسی آرت‌دکو و فویل طلایی",
    "palette": {
      "base": "black",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "دفترچه دعا",
      "description": "جلد دفترچه باز و دو صفحه ورق می‌خورند تا صفحه دعوت برسد"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "دفترچه دعا: جلد دفترچه باز و دو صفحه ورق می‌خورند تا صفحه دعوت برسد",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-080",
    "slug": "traditional-ice-crystal-10",
    "name": {
      "fa": "مراسم مذهبی/سنتی کریستال یخی 10",
      "en": "Ice Crystal مراسم مذهبی/سنتی 10"
    },
    "category": "traditional",
    "style": {
      "fa": "کریستال یخی",
      "en": "Ice Crystal"
    },
    "visual_direction": "شفافیت کریستالی، لایه‌های شیشه‌ای و نقره سرد",
    "palette": {
      "base": "ice",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "گل و شمع",
      "description": "شمع روشن می‌شود؛ گل‌ها باز می‌شوند و کارت از پایین بالا می‌آید"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "گل و شمع: شمع روشن می‌شود؛ گل‌ها باز می‌شوند و کارت از پایین بالا می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-081",
    "slug": "seasonal-pearl-&-satin-01",
    "name": {
      "fa": "مهمانی فصلی مروارید و ساتن 01",
      "en": "Pearl & Satin مهمانی فصلی 01"
    },
    "category": "seasonal",
    "style": {
      "fa": "مروارید و ساتن",
      "en": "Pearl & Satin"
    },
    "visual_direction": "مرواریدهای ریز، ساتن عاجی و نور نرم",
    "palette": {
      "base": "ivory",
      "accent": "champagne"
    },
    "opening_mechanic": {
      "fa": "برگ‌های پاییزی",
      "description": "برگ‌ها از قاب کنار می‌روند و کارت زیر لایه برگ‌ها آشکار می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "برگ‌های پاییزی: برگ‌ها از قاب کنار می‌روند و کارت زیر لایه برگ‌ها آشکار می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-082",
    "slug": "seasonal-velvet-night-02",
    "name": {
      "fa": "مهمانی فصلی شب مخملی 02",
      "en": "Velvet Night مهمانی فصلی 02"
    },
    "category": "seasonal",
    "style": {
      "fa": "شب مخملی",
      "en": "Velvet Night"
    },
    "visual_direction": "مخمل سرمه‌ای، نقره برس‌خورده و نور نقطه‌ای",
    "palette": {
      "base": "midnight",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "دانه برف",
      "description": "بلور برف می‌چرخد و به پنجره‌ای تبدیل می‌شود که کارت را نشان می‌دهد"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "دانه برف: بلور برف می‌چرخد و به پنجره‌ای تبدیل می‌شود که کارت را نشان می‌دهد",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-083",
    "slug": "seasonal-rose-garden-03",
    "name": {
      "fa": "مهمانی فصلی باغ رز 03",
      "en": "Rose Garden مهمانی فصلی 03"
    },
    "category": "seasonal",
    "style": {
      "fa": "باغ رز",
      "en": "Rose Garden"
    },
    "visual_direction": "رز برجسته، کاغذ پنبه‌ای و روبان صورتی",
    "palette": {
      "base": "blush",
      "accent": "rose-gold"
    },
    "opening_mechanic": {
      "fa": "شکوفه بهاری",
      "description": "غنچه باز می‌شود و گلبرگ‌ها کارت را در مرکز قاب می‌گیرند"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "شکوفه بهاری: غنچه باز می‌شود و گلبرگ‌ها کارت را در مرکز قاب می‌گیرند",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-084",
    "slug": "seasonal-royal-emerald-04",
    "name": {
      "fa": "مهمانی فصلی زمرد سلطنتی 04",
      "en": "Royal Emerald مهمانی فصلی 04"
    },
    "category": "seasonal",
    "style": {
      "fa": "زمرد سلطنتی",
      "en": "Royal Emerald"
    },
    "visual_direction": "زمرد تیره، طلاکوب ظریف و نقش اسلیمی",
    "palette": {
      "base": "emerald",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "صدف تابستانی",
      "description": "صدف باز می‌شود و کارت مرواریدی از داخل آن بالا می‌آید"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "صدف تابستانی: صدف باز می‌شود و کارت مرواریدی از داخل آن بالا می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-085",
    "slug": "seasonal-stone-minimal-05",
    "name": {
      "fa": "مهمانی فصلی مینیمال سنگی 05",
      "en": "Stone Minimal مهمانی فصلی 05"
    },
    "category": "seasonal",
    "style": {
      "fa": "مینیمال سنگی",
      "en": "Stone Minimal"
    },
    "visual_direction": "بافت سنگ روشن، تایپوگرافی خلوت و لبه‌های تمیز",
    "palette": {
      "base": "stone",
      "accent": "black"
    },
    "opening_mechanic": {
      "fa": "کدو هالووین",
      "description": "در کدو باز می‌شود و نور نارنجی دعوت را نمایان می‌کند"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "کدو هالووین: در کدو باز می‌شود و نور نارنجی دعوت را نمایان می‌کند",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-086",
    "slug": "seasonal-sky-watercolor-06",
    "name": {
      "fa": "مهمانی فصلی آبرنگ آسمانی 06",
      "en": "Sky Watercolor مهمانی فصلی 06"
    },
    "category": "seasonal",
    "style": {
      "fa": "آبرنگ آسمانی",
      "en": "Sky Watercolor"
    },
    "visual_direction": "آبرنگ محو، ابرهای لطیف و کاغذ نیمه‌شفاف",
    "palette": {
      "base": "sky",
      "accent": "pearl"
    },
    "opening_mechanic": {
      "fa": "درخت کریسمس",
      "description": "شاخه‌ها کنار می‌روند و جعبه هدیه زیر درخت باز می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "درخت کریسمس: شاخه‌ها کنار می‌روند و جعبه هدیه زیر درخت باز می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-087",
    "slug": "seasonal-persian-termeh-07",
    "name": {
      "fa": "مهمانی فصلی ترمه ایرانی 07",
      "en": "Persian Termeh مهمانی فصلی 07"
    },
    "category": "seasonal",
    "style": {
      "fa": "ترمه ایرانی",
      "en": "Persian Termeh"
    },
    "visual_direction": "ترمه الهام‌گرفته از بته‌جقه و قاب معماری ایرانی",
    "palette": {
      "base": "plum",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "چراغ فانوسی",
      "description": "فانوس‌ها یکی‌یکی روشن می‌شوند و پنل اصلی نمایان می‌شود"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "چراغ فانوسی: فانوس‌ها یکی‌یکی روشن می‌شوند و پنل اصلی نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-088",
    "slug": "seasonal-botanical-08",
    "name": {
      "fa": "مهمانی فصلی گیاه‌شناسی 08",
      "en": "Botanical مهمانی فصلی 08"
    },
    "category": "seasonal",
    "style": {
      "fa": "گیاه‌شناسی",
      "en": "Botanical"
    },
    "visual_direction": "برگ‌های برجسته، کاغذ بازیافتی لوکس و مس مات",
    "palette": {
      "base": "sage",
      "accent": "copper"
    },
    "opening_mechanic": {
      "fa": "چتر بارانی",
      "description": "چتر باز می‌شود؛ قطره‌ها کنار می‌روند و کارت زیر آن ظاهر می‌شود"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "چتر بارانی: چتر باز می‌شود؛ قطره‌ها کنار می‌روند و کارت زیر آن ظاهر می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-089",
    "slug": "seasonal-art-deco-09",
    "name": {
      "fa": "مهمانی فصلی آرت‌دکو 09",
      "en": "Art Deco مهمانی فصلی 09"
    },
    "category": "seasonal",
    "style": {
      "fa": "آرت‌دکو",
      "en": "Art Deco"
    },
    "visual_direction": "خطوط هندسی آرت‌دکو و فویل طلایی",
    "palette": {
      "base": "black",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "باد گرم کویر",
      "description": "لایه شن کنار می‌رود و کارت از زیر نقش برجسته بیرون می‌آید"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "باد گرم کویر: لایه شن کنار می‌رود و کارت از زیر نقش برجسته بیرون می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-090",
    "slug": "seasonal-ice-crystal-10",
    "name": {
      "fa": "مهمانی فصلی کریستال یخی 10",
      "en": "Ice Crystal مهمانی فصلی 10"
    },
    "category": "seasonal",
    "style": {
      "fa": "کریستال یخی",
      "en": "Ice Crystal"
    },
    "visual_direction": "شفافیت کریستالی، لایه‌های شیشه‌ای و نقره سرد",
    "palette": {
      "base": "ice",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "موج دریا",
      "description": "موج به دو طرف می‌شکند و کارت شیشه‌ای از زیر آب بالا می‌آید"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "موج دریا: موج به دو طرف می‌شکند و کارت شیشه‌ای از زیر آب بالا می‌آید",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-091",
    "slug": "private-party-pearl-&-satin-01",
    "name": {
      "fa": "مهمانی خصوصی و دوستانه مروارید و ساتن 01",
      "en": "Pearl & Satin مهمانی خصوصی و دوستانه 01"
    },
    "category": "private-party",
    "style": {
      "fa": "مروارید و ساتن",
      "en": "Pearl & Satin"
    },
    "visual_direction": "مرواریدهای ریز، ساتن عاجی و نور نرم",
    "palette": {
      "base": "ivory",
      "accent": "champagne"
    },
    "opening_mechanic": {
      "fa": "پلی‌لیست",
      "description": "کاور آلبوم بالا می‌رود؛ نوار پخش حرکت می‌کند و کارت باز می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پلی‌لیست: کاور آلبوم بالا می‌رود؛ نوار پخش حرکت می‌کند و کارت باز می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-092",
    "slug": "private-party-velvet-night-02",
    "name": {
      "fa": "مهمانی خصوصی و دوستانه شب مخملی 02",
      "en": "Velvet Night مهمانی خصوصی و دوستانه 02"
    },
    "category": "private-party",
    "style": {
      "fa": "شب مخملی",
      "en": "Velvet Night"
    },
    "visual_direction": "مخمل سرمه‌ای، نقره برس‌خورده و نور نقطه‌ای",
    "palette": {
      "base": "midnight",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "پاسپورت سفر",
      "description": "پاسپورت باز می‌شود؛ مهرهای سفر ظاهر و صفحه دعوت نمایان می‌شود"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پاسپورت سفر: پاسپورت باز می‌شود؛ مهرهای سفر ظاهر و صفحه دعوت نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-093",
    "slug": "private-party-rose-garden-03",
    "name": {
      "fa": "مهمانی خصوصی و دوستانه باغ رز 03",
      "en": "Rose Garden مهمانی خصوصی و دوستانه 03"
    },
    "category": "private-party",
    "style": {
      "fa": "باغ رز",
      "en": "Rose Garden"
    },
    "visual_direction": "رز برجسته، کاغذ پنبه‌ای و روبان صورتی",
    "palette": {
      "base": "blush",
      "accent": "rose-gold"
    },
    "opening_mechanic": {
      "fa": "بلیط کنسرت",
      "description": "بلیط از شکاف بیرون می‌آید؛ لبه پرفراژ جدا و جزئیات دیده می‌شود"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "بلیط کنسرت: بلیط از شکاف بیرون می‌آید؛ لبه پرفراژ جدا و جزئیات دیده می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-094",
    "slug": "private-party-royal-emerald-04",
    "name": {
      "fa": "مهمانی خصوصی و دوستانه زمرد سلطنتی 04",
      "en": "Royal Emerald مهمانی خصوصی و دوستانه 04"
    },
    "category": "private-party",
    "style": {
      "fa": "زمرد سلطنتی",
      "en": "Royal Emerald"
    },
    "visual_direction": "زمرد تیره، طلاکوب ظریف و نقش اسلیمی",
    "palette": {
      "base": "emerald",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "دوربین فوری",
      "description": "فلاش می‌زند؛ عکس ظاهر می‌شود و پشت عکس اطلاعات جشن قرار دارد"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "دوربین فوری: فلاش می‌زند؛ عکس ظاهر می‌شود و پشت عکس اطلاعات جشن قرار دارد",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-095",
    "slug": "private-party-stone-minimal-05",
    "name": {
      "fa": "مهمانی خصوصی و دوستانه مینیمال سنگی 05",
      "en": "Stone Minimal مهمانی خصوصی و دوستانه 05"
    },
    "category": "private-party",
    "style": {
      "fa": "مینیمال سنگی",
      "en": "Stone Minimal"
    },
    "visual_direction": "بافت سنگ روشن، تایپوگرافی خلوت و لبه‌های تمیز",
    "palette": {
      "base": "stone",
      "accent": "black"
    },
    "opening_mechanic": {
      "fa": "نقشه شهر",
      "description": "نقشه تا می‌شود؛ مسیر روشن و مقصد به کارت دعوت تبدیل می‌شود"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "نقشه شهر: نقشه تا می‌شود؛ مسیر روشن و مقصد به کارت دعوت تبدیل می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-096",
    "slug": "private-party-sky-watercolor-06",
    "name": {
      "fa": "مهمانی خصوصی و دوستانه آبرنگ آسمانی 06",
      "en": "Sky Watercolor مهمانی خصوصی و دوستانه 06"
    },
    "category": "private-party",
    "style": {
      "fa": "آبرنگ آسمانی",
      "en": "Sky Watercolor"
    },
    "visual_direction": "آبرنگ محو، ابرهای لطیف و کاغذ نیمه‌شفاف",
    "palette": {
      "base": "sky",
      "accent": "pearl"
    },
    "opening_mechanic": {
      "fa": "کارت بازی",
      "description": "کارت‌ها بر می‌گردند؛ کارت ویژه در مرکز باز می‌شود"
    },
    "duration_seconds": 9,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "کارت بازی: کارت‌ها بر می‌گردند؛ کارت ویژه در مرکز باز می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-097",
    "slug": "private-party-persian-termeh-07",
    "name": {
      "fa": "مهمانی خصوصی و دوستانه ترمه ایرانی 07",
      "en": "Persian Termeh مهمانی خصوصی و دوستانه 07"
    },
    "category": "private-party",
    "style": {
      "fa": "ترمه ایرانی",
      "en": "Persian Termeh"
    },
    "visual_direction": "ترمه الهام‌گرفته از بته‌جقه و قاب معماری ایرانی",
    "palette": {
      "base": "plum",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "پیام رمزگذاری‌شده",
      "description": "قفل رمز باز می‌شود و پیام دعوت از حالت محو خارج می‌شود"
    },
    "duration_seconds": 11,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "پیام رمزگذاری‌شده: قفل رمز باز می‌شود و پیام دعوت از حالت محو خارج می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-098",
    "slug": "private-party-botanical-08",
    "name": {
      "fa": "مهمانی خصوصی و دوستانه گیاه‌شناسی 08",
      "en": "Botanical مهمانی خصوصی و دوستانه 08"
    },
    "category": "private-party",
    "style": {
      "fa": "گیاه‌شناسی",
      "en": "Botanical"
    },
    "visual_direction": "برگ‌های برجسته، کاغذ بازیافتی لوکس و مس مات",
    "palette": {
      "base": "sage",
      "accent": "copper"
    },
    "opening_mechanic": {
      "fa": "جعبه پیتزا لوکس",
      "description": "در جعبه بالا می‌رود و کارت داخل درِ جعبه نمایان می‌شود"
    },
    "duration_seconds": 13,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "جعبه پیتزا لوکس: در جعبه بالا می‌رود و کارت داخل درِ جعبه نمایان می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-099",
    "slug": "private-party-art-deco-09",
    "name": {
      "fa": "مهمانی خصوصی و دوستانه آرت‌دکو 09",
      "en": "Art Deco مهمانی خصوصی و دوستانه 09"
    },
    "category": "private-party",
    "style": {
      "fa": "آرت‌دکو",
      "en": "Art Deco"
    },
    "visual_direction": "خطوط هندسی آرت‌دکو و فویل طلایی",
    "palette": {
      "base": "black",
      "accent": "gold"
    },
    "opening_mechanic": {
      "fa": "ویترین نئون",
      "description": "شیشه ویترین کنار می‌رود و کارت پشت آن روشن می‌شود"
    },
    "duration_seconds": 15,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "ویترین نئون: شیشه ویترین کنار می‌رود و کارت پشت آن روشن می‌شود",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  },
  {
    "id": "showcase-100",
    "slug": "private-party-ice-crystal-10",
    "name": {
      "fa": "مهمانی خصوصی و دوستانه کریستال یخی 10",
      "en": "Ice Crystal مهمانی خصوصی و دوستانه 10"
    },
    "category": "private-party",
    "style": {
      "fa": "کریستال یخی",
      "en": "Ice Crystal"
    },
    "visual_direction": "شفافیت کریستالی، لایه‌های شیشه‌ای و نقره سرد",
    "palette": {
      "base": "ice",
      "accent": "silver"
    },
    "opening_mechanic": {
      "fa": "دیسک چرخان",
      "description": "دیسک نیم‌دور می‌چرخد و پنل مخفی دعوت را نشان می‌دهد"
    },
    "duration_seconds": 7,
    "stages": [
      {
        "order": 1,
        "scene": "closed-object",
        "title": "نمای آغاز",
        "description": "پاکت/شیء در حالت بسته، نورپردازی و بافت متریال معرفی می‌شود.",
        "interaction": "tap-or-swipe"
      },
      {
        "order": 2,
        "scene": "unlock",
        "title": "آزادسازی قفل یا لایه",
        "description": "دیسک چرخان: دیسک نیم‌دور می‌چرخد و پنل مخفی دعوت را نشان می‌دهد",
        "interaction": "tap"
      },
      {
        "order": 3,
        "scene": "reveal",
        "title": "آشکارشدن لایه میانی",
        "description": "لایه تزئینی به‌آرامی کنار می‌رود؛ سایه و عمق کاغذ حفظ می‌شود.",
        "interaction": "drag-or-auto"
      },
      {
        "order": 4,
        "scene": "card-emergence",
        "title": "ورود کارت اصلی",
        "description": "کارت با حرکت نرم از محفظه بیرون می‌آید و اندکی مکث می‌کند.",
        "interaction": "auto"
      },
      {
        "order": 5,
        "scene": "final-presentation",
        "title": "نمای نهایی",
        "description": "کارت کامل و خوانا در مرکز قرار می‌گیرد؛ دکمه پاسخ‌گویی و جزئیات رویداد ظاهر می‌شوند.",
        "interaction": "continue"
      }
    ],
    "editable_fields": [
      "نام میزبان",
      "نام مهمان",
      "تاریخ",
      "ساعت",
      "مکان",
      "متن دعوت",
      "تصویر اصلی"
    ],
    "responsive": true,
    "reduced_motion_fallback": "crossfade",
    "audio": {
      "music_optional": true,
      "sfx_optional": true,
      "autoplay": false
    }
  }
];
