# بسته ۴۰ قالب جدید INVITÉ

این بسته ۴۰ تعریف قالب جدید دارد، با ترکیب‌های رنگی و سناریوهای بازشدن متنوع:
مهر مومی، روبان، جعبه، کارت آکاردئونی، اوریگامی، طومار، دفترچه، پاکت پنجره‌ای، صفحه وینیل، کلاکت سینمایی، نقشه تاخورده، پاپ‌آپ و موارد دیگر.

## نصب
1. فایل `forty-more-templates.ts` را در مسیر `src/modules/template-engine/` قرار دهید.
2. در محل تعریف آرایه قالب‌های بازار، این ماژول را import کنید:
   `import { FORTY_MORE_TEMPLATES } from '../template-engine/forty-more-templates';`
3. آرایه را به فهرست فعلی اضافه کنید:
   `const MARKETPLACE_TEMPLATES = [...EXISTING_TEMPLATES, ...FORTY_MORE_TEMPLATES];`
   نام `EXISTING_TEMPLATES` را با نام واقعی آرایه فعلی پروژه جایگزین کنید.
4. `npm run typecheck` و `npm run build` را اجرا کنید.

## محدودیت مهم
این فایل، داده‌های قالب و تنظیمات sequence را اضافه می‌کند؛ scene IDها تنها زمانی انیمیشن واقعی اجرا می‌کنند که cinematic engine همان sceneها را پیاده‌سازی کرده باشد. همچنین شناسه موسیقی‌ها باید در Audio Library ثبت شوند. این بسته روی مخزن GitHub اعمال نشده و Build پروژه اصلی هنوز اجرا نشده است.
