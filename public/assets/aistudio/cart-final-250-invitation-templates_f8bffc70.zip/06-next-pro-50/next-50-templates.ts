export type Next50Stage = {
  stage: "closed_state" | "invitation_tease" | "opening_mechanism" | "card_reveal" | "final_presentation";
  duration_ms: number;
  description: string;
};

export type Next50Template = {
  id: string;
  slug: string;
  name: { en: string; fa: string };
  category: string;
  art_direction: string;
  palette: string[];
  storyboard: Next50Stage[];
  editable_fields: string[];
  interaction: { desktop: string; mobile: string; skip: boolean; replay: boolean; reduced_motion: string };
  audio: { music_default: string; sound_effects_optional: boolean };
  rtl_ready: boolean;
  mobile_first: boolean;
  implementation_note: string;
};

export const next50Templates: Next50Template[] = [
  {
    "id": "next50-001",
    "slug": "ivory-cathedral",
    "name": {
      "en": "Ivory Cathedral",
      "fa": "کلیسای عاجی"
    },
    "category": "wedding",
    "art_direction": "معماری",
    "palette": [
      "#F4EFE6",
      "#B89B69",
      "#292725"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ ورودی کلیسایی عاجی با پنجره‌های بلند و نور صبحگاهی"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "ورودی کلیسایی عاجی با پنجره‌های بلند و نور صبحگاهی"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-002",
    "slug": "the-secret-garden-gate",
    "name": {
      "en": "The Secret Garden Gate",
      "fa": "دروازه باغ پنهان"
    },
    "category": "wedding",
    "art_direction": "باغی",
    "palette": [
      "#E9E1D6",
      "#A78B70",
      "#3B3430"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ دروازه آهنی باغ با پیچک‌هایی که آرام کنار می‌روند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "دروازه آهنی باغ با پیچک‌هایی که آرام کنار می‌روند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-003",
    "slug": "pearl-tide",
    "name": {
      "en": "Pearl Tide",
      "fa": "موج مروارید"
    },
    "category": "wedding",
    "art_direction": "دریایی",
    "palette": [
      "#F7F2EE",
      "#C6A7A0",
      "#51434A"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ صدف صدفی باز می‌شود و کارت از میان لایه‌های مرواریدی بیرون می‌آید"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "صدف صدفی باز می‌شود و کارت از میان لایه‌های مرواریدی بیرون می‌آید"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-004",
    "slug": "the-heirloom-chest",
    "name": {
      "en": "The Heirloom Chest",
      "fa": "صندوق یادگار"
    },
    "category": "wedding",
    "art_direction": "کلاسیک",
    "palette": [
      "#101820",
      "#C7A96B",
      "#F4EBDD"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ صندوقچه چوبی ظریف با آستر مخمل و کارت حکاکی‌شده"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "صندوقچه چوبی ظریف با آستر مخمل و کارت حکاکی‌شده"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-005",
    "slug": "starlit-vows",
    "name": {
      "en": "Starlit Vows",
      "fa": "سوگند زیر ستاره‌ها"
    },
    "category": "wedding",
    "art_direction": "آسمانی",
    "palette": [
      "#E8E2D4",
      "#637A68",
      "#2F3A32"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ آسمان شب با صورت‌های فلکی که مسیر بازشدن کارت را روشن می‌کنند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "آسمان شب با صورت‌های فلکی که مسیر بازشدن کارت را روشن می‌کنند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-006",
    "slug": "white-camellia",
    "name": {
      "en": "White Camellia",
      "fa": "کاملیای سفید"
    },
    "category": "wedding",
    "art_direction": "گل‌آرایی",
    "palette": [
      "#F3E7D7",
      "#B77B61",
      "#43332D"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ گلبرگ‌های کاملیا لایه‌لایه کنار می‌روند و دعوت‌نامه نمایان می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "گلبرگ‌های کاملیا لایه‌لایه کنار می‌روند و دعوت‌نامه نمایان می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-007",
    "slug": "the-marble-atrium",
    "name": {
      "en": "The Marble Atrium",
      "fa": "تالار مرمر"
    },
    "category": "wedding",
    "art_direction": "معماری",
    "palette": [
      "#E6EDF0",
      "#8CA6B2",
      "#263746"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ درهای مرمری با رگه‌های طبیعی و انعکاس نور طلایی"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "درهای مرمری با رگه‌های طبیعی و انعکاس نور طلایی"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-008",
    "slug": "satin-pavilion",
    "name": {
      "en": "Satin Pavilion",
      "fa": "پاویون ساتن"
    },
    "category": "wedding",
    "art_direction": "پارچه‌ای",
    "palette": [
      "#F1E8D9",
      "#B6A17B",
      "#514638"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ پرده‌های ساتن از دو طرف کنار می‌روند و کارت در مرکز می‌درخشد"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "پرده‌های ساتن از دو طرف کنار می‌روند و کارت در مرکز می‌درخشد"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-009",
    "slug": "the-swan-ceremony",
    "name": {
      "en": "The Swan Ceremony",
      "fa": "مراسم قوها"
    },
    "category": "wedding",
    "art_direction": "رمانتیک",
    "palette": [
      "#F4EFE6",
      "#B89B69",
      "#292725"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ دو قو روی آب حرکت می‌کنند و حلقه‌ای از موج، کارت را آشکار می‌کند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "دو قو روی آب حرکت می‌کنند و حلقه‌ای از موج، کارت را آشکار می‌کند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-010",
    "slug": "antique-postmark",
    "name": {
      "en": "Antique Postmark",
      "fa": "مهر پستی عتیقه"
    },
    "category": "wedding",
    "art_direction": "نوستالژیک",
    "palette": [
      "#E9E1D6",
      "#A78B70",
      "#3B3430"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ پاکت نامه قدیمی با تمبر برجسته و مهر مومی باز می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "پاکت نامه قدیمی با تمبر برجسته و مهر مومی باز می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-011",
    "slug": "the-ring-constellation",
    "name": {
      "en": "The Ring Constellation",
      "fa": "صورت فلکی حلقه"
    },
    "category": "engagement",
    "art_direction": "جواهر",
    "palette": [
      "#F7F2EE",
      "#C6A7A0",
      "#51434A"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ ذرات نور به شکل حلقه نامزدی جمع می‌شوند و قاب دعوت را می‌سازند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "ذرات نور به شکل حلقه نامزدی جمع می‌شوند و قاب دعوت را می‌سازند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-012",
    "slug": "blush-atelier",
    "name": {
      "en": "Blush Atelier",
      "fa": "آتلیه رزگلد"
    },
    "category": "engagement",
    "art_direction": "مینیمال لوکس",
    "palette": [
      "#101820",
      "#C7A96B",
      "#F4EBDD"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ جعبه صورتی مات با کشوی مخفی و کارت برجسته"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "جعبه صورتی مات با کشوی مخفی و کارت برجسته"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-013",
    "slug": "the-golden-thread",
    "name": {
      "en": "The Golden Thread",
      "fa": "نخ طلایی"
    },
    "category": "engagement",
    "art_direction": "هنری",
    "palette": [
      "#E8E2D4",
      "#637A68",
      "#2F3A32"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ نخ طلایی دور کارت پیچیده و با کشیده‌شدن آن باز می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "نخ طلایی دور کارت پیچیده و با کشیده‌شدن آن باز می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-014",
    "slug": "secret-initials",
    "name": {
      "en": "Secret Initials",
      "fa": "حروف اول پنهان"
    },
    "category": "engagement",
    "art_direction": "مونوگرام",
    "palette": [
      "#F3E7D7",
      "#B77B61",
      "#43332D"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ مونوگرام برجسته روی جلد می‌چرخد و صفحه داخلی نمایان می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "مونوگرام برجسته روی جلد می‌چرخد و صفحه داخلی نمایان می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-015",
    "slug": "crystal-keepsake",
    "name": {
      "en": "Crystal Keepsake",
      "fa": "یادگار کریستالی"
    },
    "category": "engagement",
    "art_direction": "کریستالی",
    "palette": [
      "#E6EDF0",
      "#8CA6B2",
      "#263746"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ بلور شفاف نور را می‌شکند و دعوت‌نامه را از درون آشکار می‌کند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "بلور شفاف نور را می‌شکند و دعوت‌نامه را از درون آشکار می‌کند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-016",
    "slug": "disco-royale",
    "name": {
      "en": "Disco Royale",
      "fa": "دیسکو رویال"
    },
    "category": "birthday_adult",
    "art_direction": "موسیقی",
    "palette": [
      "#F1E8D9",
      "#B6A17B",
      "#514638"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ گوی آینه‌ای آرام می‌چرخد و نورهای منعکس‌شده عنوان را می‌سازند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "گوی آینه‌ای آرام می‌چرخد و نورهای منعکس‌شده عنوان را می‌سازند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-017",
    "slug": "black-champagne",
    "name": {
      "en": "Black Champagne",
      "fa": "شامپاین مشکی"
    },
    "category": "birthday_adult",
    "art_direction": "شبانه",
    "palette": [
      "#F4EFE6",
      "#B89B69",
      "#292725"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ بطری مینیمال و لیوان کریستالی با افکت حباب‌های ظریف"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "بطری مینیمال و لیوان کریستالی با افکت حباب‌های ظریف"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-018",
    "slug": "the-art-collector",
    "name": {
      "en": "The Art Collector",
      "fa": "کلکسیونر هنر"
    },
    "category": "birthday_adult",
    "art_direction": "گالری",
    "palette": [
      "#E9E1D6",
      "#A78B70",
      "#3B3430"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ تابلوی پوشیده با پارچه کنار می‌رود و دعوت‌نامه مثل اثر هنری دیده می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "تابلوی پوشیده با پارچه کنار می‌رود و دعوت‌نامه مثل اثر هنری دیده می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-019",
    "slug": "retro-cinema-night",
    "name": {
      "en": "Retro Cinema Night",
      "fa": "شب سینمای رترو"
    },
    "category": "birthday_adult",
    "art_direction": "سینمایی",
    "palette": [
      "#F7F2EE",
      "#C6A7A0",
      "#51434A"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ پرده سینما باز می‌شود و کارت با نور پروژکتور ظاهر می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "پرده سینما باز می‌شود و کارت با نور پروژکتور ظاهر می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-020",
    "slug": "midnight-bloom",
    "name": {
      "en": "Midnight Bloom",
      "fa": "شکوفه نیمه‌شب"
    },
    "category": "birthday_adult",
    "art_direction": "گل‌دار",
    "palette": [
      "#101820",
      "#C7A96B",
      "#F4EBDD"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ غنچه تیره در نور ماه باز می‌شود و متن در مرکز گلبرگ‌ها قرار می‌گیرد"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "غنچه تیره در نور ماه باز می‌شود و متن در مرکز گلبرگ‌ها قرار می‌گیرد"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-021",
    "slug": "cloud-castle",
    "name": {
      "en": "Cloud Castle",
      "fa": "قلعه ابری"
    },
    "category": "birthday_kids",
    "art_direction": "فانتزی",
    "palette": [
      "#E8E2D4",
      "#637A68",
      "#2F3A32"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ ابرها کنار می‌روند و قلعه‌ای رنگی با دروازه متحرک نمایان می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "ابرها کنار می‌روند و قلعه‌ای رنگی با دروازه متحرک نمایان می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-022",
    "slug": "robot-workshop",
    "name": {
      "en": "Robot Workshop",
      "fa": "کارگاه ربات‌ها"
    },
    "category": "birthday_kids",
    "art_direction": "رباتیک",
    "palette": [
      "#F3E7D7",
      "#B77B61",
      "#43332D"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ قطعات ربات کنار هم مونتاژ می‌شوند و نمایشگر دعوت را روشن می‌کند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "قطعات ربات کنار هم مونتاژ می‌شوند و نمایشگر دعوت را روشن می‌کند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-023",
    "slug": "jungle-safari",
    "name": {
      "en": "Jungle Safari",
      "fa": "سافاری جنگل"
    },
    "category": "birthday_kids",
    "art_direction": "ماجراجویی",
    "palette": [
      "#E6EDF0",
      "#8CA6B2",
      "#263746"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ برگ‌های بزرگ کنار می‌روند و ردپاها مهمان را به کارت می‌رسانند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "برگ‌های بزرگ کنار می‌روند و ردپاها مهمان را به کارت می‌رسانند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-024",
    "slug": "rainbow-train",
    "name": {
      "en": "Rainbow Train",
      "fa": "قطار رنگین‌کمان"
    },
    "category": "birthday_kids",
    "art_direction": "بازیگوش",
    "palette": [
      "#F1E8D9",
      "#B6A17B",
      "#514638"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ قطار کوچکی از تونل رنگی عبور می‌کند و واگن آخر کارت را حمل می‌کند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "قطار کوچکی از تونل رنگی عبور می‌کند و واگن آخر کارت را حمل می‌کند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-025",
    "slug": "pirate-treasure",
    "name": {
      "en": "Pirate Treasure",
      "fa": "گنج دزدان دریایی"
    },
    "category": "birthday_kids",
    "art_direction": "دریایی",
    "palette": [
      "#F4EFE6",
      "#B89B69",
      "#292725"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ نقشه گنج باز می‌شود و صندوق با قفل ساده نمایان می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "نقشه گنج باز می‌شود و صندوق با قفل ساده نمایان می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-026",
    "slug": "little-star-nursery",
    "name": {
      "en": "Little Star Nursery",
      "fa": "اتاق ستاره کوچولو"
    },
    "category": "baby_shower",
    "art_direction": "لطیف",
    "palette": [
      "#E9E1D6",
      "#A78B70",
      "#3B3430"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ آویز ستاره بالای گهواره می‌چرخد و کارت از زیر آن نمایان می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "آویز ستاره بالای گهواره می‌چرخد و کارت از زیر آن نمایان می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-027",
    "slug": "cloud-nine-letter",
    "name": {
      "en": "Cloud Nine Letter",
      "fa": "نامه ابر نهم"
    },
    "category": "baby_shower",
    "art_direction": "ابر و آسمان",
    "palette": [
      "#F7F2EE",
      "#C6A7A0",
      "#51434A"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ پاکت ابری با لایه‌های پنبه‌ای و تایپوگرافی نرم باز می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "پاکت ابری با لایه‌های پنبه‌ای و تایپوگرافی نرم باز می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-028",
    "slug": "tiny-footprints",
    "name": {
      "en": "Tiny Footprints",
      "fa": "ردپای کوچولو"
    },
    "category": "baby_shower",
    "art_direction": "مینیمال",
    "palette": [
      "#101820",
      "#C7A96B",
      "#F4EBDD"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ ردپاهای کوچک روی کاغذ برجسته حرکت می‌کنند و به متن می‌رسند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "ردپاهای کوچک روی کاغذ برجسته حرکت می‌کنند و به متن می‌رسند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-029",
    "slug": "the-keepsake-quilt",
    "name": {
      "en": "The Keepsake Quilt",
      "fa": "لحاف یادگاری"
    },
    "category": "baby_shower",
    "art_direction": "پارچه‌ای",
    "palette": [
      "#E8E2D4",
      "#637A68",
      "#2F3A32"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ تکه‌های پارچه مثل لحاف کنار می‌روند و صفحه دعوت را می‌سازند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "تکه‌های پارچه مثل لحاف کنار می‌روند و صفحه دعوت را می‌سازند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-030",
    "slug": "moon-cradle",
    "name": {
      "en": "Moon Cradle",
      "fa": "گهواره ماه"
    },
    "category": "baby_shower",
    "art_direction": "ماه و ستاره",
    "palette": [
      "#F3E7D7",
      "#B77B61",
      "#43332D"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ هلال ماه مثل گهواره تاب می‌خورد و کارت درون آن ظاهر می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "هلال ماه مثل گهواره تاب می‌خورد و کارت درون آن ظاهر می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-031",
    "slug": "the-scholars-seal",
    "name": {
      "en": "The Scholar's Seal",
      "fa": "مهر دانش‌پژوه"
    },
    "category": "graduation",
    "art_direction": "آکادمیک",
    "palette": [
      "#E6EDF0",
      "#8CA6B2",
      "#263746"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ مهر برجسته روی جلد شکسته می‌شود و گواهی دعوت نمایان می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "مهر برجسته روی جلد شکسته می‌شود و گواهی دعوت نمایان می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-032",
    "slug": "blueprint-to-future",
    "name": {
      "en": "Blueprint to Future",
      "fa": "نقشه آینده"
    },
    "category": "graduation",
    "art_direction": "مدرن",
    "palette": [
      "#F1E8D9",
      "#B6A17B",
      "#514638"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ نقشه فنی به خطوط نورانی تبدیل می‌شود و کارت از میان آن شکل می‌گیرد"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "نقشه فنی به خطوط نورانی تبدیل می‌شود و کارت از میان آن شکل می‌گیرد"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-033",
    "slug": "the-final-chapter",
    "name": {
      "en": "The Final Chapter",
      "fa": "فصل پایانی"
    },
    "category": "graduation",
    "art_direction": "کتاب",
    "palette": [
      "#F4EFE6",
      "#B89B69",
      "#292725"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ کتاب قطور باز می‌شود و صفحه پایانی با جزئیات مراسم نمایان می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "کتاب قطور باز می‌شود و صفحه پایانی با جزئیات مراسم نمایان می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-034",
    "slug": "laurel-&-light",
    "name": {
      "en": "Laurel & Light",
      "fa": "برگ‌بو و نور"
    },
    "category": "graduation",
    "art_direction": "کلاسیک",
    "palette": [
      "#E9E1D6",
      "#A78B70",
      "#3B3430"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ تاج برگ‌بو دور عنوان شکل می‌گیرد و نور از پشت آن می‌تابد"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "تاج برگ‌بو دور عنوان شکل می‌گیرد و نور از پشت آن می‌تابد"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-035",
    "slug": "caps-in-the-sky",
    "name": {
      "en": "Caps in the Sky",
      "fa": "کلاه‌ها در آسمان"
    },
    "category": "graduation",
    "art_direction": "شاد",
    "palette": [
      "#F7F2EE",
      "#C6A7A0",
      "#51434A"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ کلاه‌های فارغ‌التحصیلی بالا می‌روند و کارت روی روبان فرود می‌آید"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "کلاه‌های فارغ‌التحصیلی بالا می‌روند و کارت روی روبان فرود می‌آید"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-036",
    "slug": "the-opera-curtain",
    "name": {
      "en": "The Opera Curtain",
      "fa": "پرده اپرا"
    },
    "category": "gala",
    "art_direction": "نمایشی",
    "palette": [
      "#101820",
      "#C7A96B",
      "#F4EBDD"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ پرده مخمل قرمز با حرکت آهسته باز می‌شود و صحنه دعوت آشکار می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "پرده مخمل قرمز با حرکت آهسته باز می‌شود و صحنه دعوت آشکار می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-037",
    "slug": "obsidian-gallery",
    "name": {
      "en": "Obsidian Gallery",
      "fa": "گالری ابسیدین"
    },
    "category": "gala",
    "art_direction": "مشکی لوکس",
    "palette": [
      "#E8E2D4",
      "#637A68",
      "#2F3A32"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ پنل‌های سنگی تیره با لبه‌های فلزی باز می‌شوند و اطلاعات نمایان می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "پنل‌های سنگی تیره با لبه‌های فلزی باز می‌شوند و اطلاعات نمایان می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-038",
    "slug": "the-crystal-ballroom",
    "name": {
      "en": "The Crystal Ballroom",
      "fa": "تالار کریستال"
    },
    "category": "gala",
    "art_direction": "کریستالی",
    "palette": [
      "#F3E7D7",
      "#B77B61",
      "#43332D"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ لوستر کریستالی روشن می‌شود و انعکاس‌ها قاب دعوت را می‌سازند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "لوستر کریستالی روشن می‌شود و انعکاس‌ها قاب دعوت را می‌سازند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-039",
    "slug": "golden-ticket-no.-1",
    "name": {
      "en": "Golden Ticket No. 1",
      "fa": "بلیط طلایی شماره یک"
    },
    "category": "gala",
    "art_direction": "بلیطی",
    "palette": [
      "#E6EDF0",
      "#8CA6B2",
      "#263746"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ بلیط فلزی از دستگاه تشریفاتی بیرون می‌آید و جزئیات روی آن ظاهر می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "بلیط فلزی از دستگاه تشریفاتی بیرون می‌آید و جزئیات روی آن ظاهر می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-040",
    "slug": "velvet-rope",
    "name": {
      "en": "Velvet Rope",
      "fa": "طناب مخملی"
    },
    "category": "gala",
    "art_direction": "VIP",
    "palette": [
      "#F1E8D9",
      "#B6A17B",
      "#514638"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ طناب تشریفاتی کنار می‌رود و کارت VIP با افکت برجسته ظاهر می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "طناب تشریفاتی کنار می‌رود و کارت VIP با افکت برجسته ظاهر می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-041",
    "slug": "persian-mirrorwork",
    "name": {
      "en": "Persian Mirrorwork",
      "fa": "آینه‌کاری ایرانی"
    },
    "category": "traditional",
    "art_direction": "ایرانی",
    "palette": [
      "#F4EFE6",
      "#B89B69",
      "#292725"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ قطعات آینه‌کاری به‌آرامی کنار هم می‌نشینند و قاب دعوت را تشکیل می‌دهند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "قطعات آینه‌کاری به‌آرامی کنار هم می‌نشینند و قاب دعوت را تشکیل می‌دهند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-042",
    "slug": "the-copper-bazaar",
    "name": {
      "en": "The Copper Bazaar",
      "fa": "بازار مسی"
    },
    "category": "traditional",
    "art_direction": "سنتی",
    "palette": [
      "#E9E1D6",
      "#A78B70",
      "#3B3430"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ کرکره مسی ظریف بالا می‌رود و کاغذ دست‌ساز نمایان می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "کرکره مسی ظریف بالا می‌رود و کاغذ دست‌ساز نمایان می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-043",
    "slug": "tilework-portal",
    "name": {
      "en": "Tilework Portal",
      "fa": "درگاه کاشی"
    },
    "category": "traditional",
    "art_direction": "کاشی‌کاری",
    "palette": [
      "#F7F2EE",
      "#C6A7A0",
      "#51434A"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ نقوش کاشی فیروزه‌ای از مرکز گسترش می‌یابند و صفحه را قاب می‌کنند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "نقوش کاشی فیروزه‌ای از مرکز گسترش می‌یابند و صفحه را قاب می‌کنند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-044",
    "slug": "the-poets-divan",
    "name": {
      "en": "The Poet's Divan",
      "fa": "دیوان شاعر"
    },
    "category": "traditional",
    "art_direction": "ادبی",
    "palette": [
      "#101820",
      "#C7A96B",
      "#F4EBDD"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ دفتر شعر با روبان نشان‌گذار باز می‌شود و متن با حرکت مرکب ظاهر می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "دفتر شعر با روبان نشان‌گذار باز می‌شود و متن با حرکت مرکب ظاهر می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-045",
    "slug": "caravanserai-night",
    "name": {
      "en": "Caravanserai Night",
      "fa": "شب کاروانسرا"
    },
    "category": "traditional",
    "art_direction": "ایرانی",
    "palette": [
      "#E8E2D4",
      "#637A68",
      "#2F3A32"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ در چوبی کاروانسرا باز می‌شود و نور فانوس مسیر را روشن می‌کند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "در چوبی کاروانسرا باز می‌شود و نور فانوس مسیر را روشن می‌کند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-046",
    "slug": "autumn-glasshouse",
    "name": {
      "en": "Autumn Glasshouse",
      "fa": "گلخانه پاییزی"
    },
    "category": "seasonal",
    "art_direction": "پاییزی",
    "palette": [
      "#F3E7D7",
      "#B77B61",
      "#43332D"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ برگ‌های کهربایی روی شیشه می‌نشینند و با پاک‌شدن بخار، دعوت آشکار می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "برگ‌های کهربایی روی شیشه می‌نشینند و با پاک‌شدن بخار، دعوت آشکار می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-047",
    "slug": "snowfall-postcard",
    "name": {
      "en": "Snowfall Postcard",
      "fa": "کارت‌پستال برفی"
    },
    "category": "seasonal",
    "art_direction": "زمستانی",
    "palette": [
      "#E6EDF0",
      "#8CA6B2",
      "#263746"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ کارت‌پستال از میان برف بیرون می‌آید و دانه‌ها آرام محو می‌شوند"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "کارت‌پستال از میان برف بیرون می‌آید و دانه‌ها آرام محو می‌شوند"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-048",
    "slug": "summer-riviera",
    "name": {
      "en": "Summer Riviera",
      "fa": "ریویِرای تابستانی"
    },
    "category": "seasonal",
    "art_direction": "تابستانی",
    "palette": [
      "#F1E8D9",
      "#B6A17B",
      "#514638"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ کارت ساحلی با سایه آفتاب و موج ملایم دریا باز می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "کارت ساحلی با سایه آفتاب و موج ملایم دریا باز می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-049",
    "slug": "the-secret-door",
    "name": {
      "en": "The Secret Door",
      "fa": "در مخفی"
    },
    "category": "private_party",
    "art_direction": "معمایی",
    "palette": [
      "#F4EFE6",
      "#B89B69",
      "#292725"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ پنل دیواری با چرخش آرام باز می‌شود و دعوت‌نامه پشت آن پنهان است"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "پنل دیواری با چرخش آرام باز می‌شود و دعوت‌نامه پشت آن پنهان است"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  },
  {
    "id": "next50-050",
    "slug": "collectors-pass",
    "name": {
      "en": "Collector's Pass",
      "fa": "کارت ورود کلکسیونر"
    },
    "category": "private_party",
    "art_direction": "اکسکلوسیو",
    "palette": [
      "#E9E1D6",
      "#A78B70",
      "#3B3430"
    ],
    "storyboard": [
      {
        "stage": "closed_state",
        "duration_ms": 650,
        "description": "نمای بسته و لوکس؛ کاور چرمی با قفل فلزی باز می‌شود و کارت دسترسی نمایان می‌شود"
      },
      {
        "stage": "invitation_tease",
        "duration_ms": 900,
        "description": "جزئیات متریال، نور و بافت به‌آرامی دیده می‌شوند؛ بدون نمایش کامل متن"
      },
      {
        "stage": "opening_mechanism",
        "duration_ms": 1250,
        "description": "کاور چرمی با قفل فلزی باز می‌شود و کارت دسترسی نمایان می‌شود"
      },
      {
        "stage": "card_reveal",
        "duration_ms": 1100,
        "description": "کارت اصلی با عمق لایه‌ای، سایه طبیعی و حرکت نرم نمایان می‌شود"
      },
      {
        "stage": "final_presentation",
        "duration_ms": 800,
        "description": "عنوان، نام میزبان، تاریخ و دکمه پاسخ‌گویی در چیدمان نهایی خوانا قرار می‌گیرند"
      }
    ],
    "editable_fields": [
      "event_title",
      "host_names",
      "date",
      "time",
      "venue",
      "description",
      "rsvp_label",
      "cover_message"
    ],
    "interaction": {
      "desktop": "pointer and keyboard",
      "mobile": "touch-first",
      "skip": true,
      "replay": true,
      "reduced_motion": "fade-only"
    },
    "audio": {
      "music_default": "off",
      "sound_effects_optional": true
    },
    "rtl_ready": true,
    "mobile_first": true,
    "implementation_note": "Storyboard specification; requires mapping to the project's validated template schema and scene renderer."
  }
];
