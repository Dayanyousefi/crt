# کاتالوگ ۵۰ قالب تازه و حرفه‌ای کارت

این بسته شامل ۵۰ کانسپت تازه با ۵ مرحله بازشدن برای هر قالب است؛ در مجموع ۲۵۰ مرحله استوری‌بورد.

## فهرست قالب‌ها

- **کلیسای عاجی** — Ivory Cathedral — `wedding` — معماری
- **دروازه باغ پنهان** — The Secret Garden Gate — `wedding` — باغی
- **موج مروارید** — Pearl Tide — `wedding` — دریایی
- **صندوق یادگار** — The Heirloom Chest — `wedding` — کلاسیک
- **سوگند زیر ستاره‌ها** — Starlit Vows — `wedding` — آسمانی
- **کاملیای سفید** — White Camellia — `wedding` — گل‌آرایی
- **تالار مرمر** — The Marble Atrium — `wedding` — معماری
- **پاویون ساتن** — Satin Pavilion — `wedding` — پارچه‌ای
- **مراسم قوها** — The Swan Ceremony — `wedding` — رمانتیک
- **مهر پستی عتیقه** — Antique Postmark — `wedding` — نوستالژیک
- **صورت فلکی حلقه** — The Ring Constellation — `engagement` — جواهر
- **آتلیه رزگلد** — Blush Atelier — `engagement` — مینیمال لوکس
- **نخ طلایی** — The Golden Thread — `engagement` — هنری
- **حروف اول پنهان** — Secret Initials — `engagement` — مونوگرام
- **یادگار کریستالی** — Crystal Keepsake — `engagement` — کریستالی
- **دیسکو رویال** — Disco Royale — `birthday_adult` — موسیقی
- **شامپاین مشکی** — Black Champagne — `birthday_adult` — شبانه
- **کلکسیونر هنر** — The Art Collector — `birthday_adult` — گالری
- **شب سینمای رترو** — Retro Cinema Night — `birthday_adult` — سینمایی
- **شکوفه نیمه‌شب** — Midnight Bloom — `birthday_adult` — گل‌دار
- **قلعه ابری** — Cloud Castle — `birthday_kids` — فانتزی
- **کارگاه ربات‌ها** — Robot Workshop — `birthday_kids` — رباتیک
- **سافاری جنگل** — Jungle Safari — `birthday_kids` — ماجراجویی
- **قطار رنگین‌کمان** — Rainbow Train — `birthday_kids` — بازیگوش
- **گنج دزدان دریایی** — Pirate Treasure — `birthday_kids` — دریایی
- **اتاق ستاره کوچولو** — Little Star Nursery — `baby_shower` — لطیف
- **نامه ابر نهم** — Cloud Nine Letter — `baby_shower` — ابر و آسمان
- **ردپای کوچولو** — Tiny Footprints — `baby_shower` — مینیمال
- **لحاف یادگاری** — The Keepsake Quilt — `baby_shower` — پارچه‌ای
- **گهواره ماه** — Moon Cradle — `baby_shower` — ماه و ستاره
- **مهر دانش‌پژوه** — The Scholar's Seal — `graduation` — آکادمیک
- **نقشه آینده** — Blueprint to Future — `graduation` — مدرن
- **فصل پایانی** — The Final Chapter — `graduation` — کتاب
- **برگ‌بو و نور** — Laurel & Light — `graduation` — کلاسیک
- **کلاه‌ها در آسمان** — Caps in the Sky — `graduation` — شاد
- **پرده اپرا** — The Opera Curtain — `gala` — نمایشی
- **گالری ابسیدین** — Obsidian Gallery — `gala` — مشکی لوکس
- **تالار کریستال** — The Crystal Ballroom — `gala` — کریستالی
- **بلیط طلایی شماره یک** — Golden Ticket No. 1 — `gala` — بلیطی
- **طناب مخملی** — Velvet Rope — `gala` — VIP
- **آینه‌کاری ایرانی** — Persian Mirrorwork — `traditional` — ایرانی
- **بازار مسی** — The Copper Bazaar — `traditional` — سنتی
- **درگاه کاشی** — Tilework Portal — `traditional` — کاشی‌کاری
- **دیوان شاعر** — The Poet's Divan — `traditional` — ادبی
- **شب کاروانسرا** — Caravanserai Night — `traditional` — ایرانی
- **گلخانه پاییزی** — Autumn Glasshouse — `seasonal` — پاییزی
- **کارت‌پستال برفی** — Snowfall Postcard — `seasonal` — زمستانی
- **ریویِرای تابستانی** — Summer Riviera — `seasonal` — تابستانی
- **در مخفی** — The Secret Door — `private_party` — معمایی
- **کارت ورود کلکسیونر** — Collector's Pass — `private_party` — اکسکلوسیو

## استاندارد تجربه
- پنج مرحله: حالت بسته، پیش‌نمایش، مکانیزم بازشدن، نمایان‌شدن کارت، نمایش نهایی.
- پشتیبانی طراحی از موبایل، RTL، ردکردن و اجرای مجدد.
- حالت کاهش حرکت برای دسترس‌پذیری.
- موسیقی به‌صورت پیش‌فرض خاموش و افکت صوتی اختیاری.

## نکته پیاده‌سازی
این‌ها مشخصات طراحی و استوری‌بورد هستند، نه انیمیشن اجرایی. برای اتصال به پروژه باید با schema واقعی قالب‌ها و موتور صحنه پروژه تطبیق داده شوند.