import type { ValidatedTemplateSpec } from './template-schema';

/**
 * Five additional, deliberately differentiated showcase templates.
 * They reuse the existing schema so they remain compatible with the current
 * renderer, studio callback, and cinematic callback.
 */
type ShowcaseDefinition = {
  id: string;
  slug: string;
  categorySlug: ValidatedTemplateSpec['categorySlug'];
  title: string;
  subtitle: string;
  titleEn: string;
  subtitleEn: string;
  titleAr: string;
  subtitleAr: string;
  names: [string, string, string];
  invitation: [string, string, string];
  date: [string, string, string];
  venue: [string, string, string];
  verse: [string, string, string];
  tags: string[];
  palette: ValidatedTemplateSpec['palette'];
  envelopeStyle: ValidatedTemplateSpec['openingSequence']['envelopeStyle'];
  sceneIds: string[];
  monogram: string;
  music: string;
  sfx: string;
  duration: number;
  easing: ValidatedTemplateSpec['openingSequence']['easingPreset'];
  price: number;
  priceUsd: number;
};

const definitions: ShowcaseDefinition[] = [
  {
    id: 'tpl_black_tie_gala',
    slug: 'black-tie-gala',
    categorySlug: 'minimal',
    title: 'شب باشکوه بلک‌تای (Black Tie Gala)',
    subtitle: 'پاکت مشکی مات، نوار ساتن شامپاینی و کارت مشکی با تایپوگرافی طلایی',
    titleEn: 'Black Tie Midnight Gala',
    subtitleEn: 'A matte-black envelope, champagne satin band, and dramatic gold typography',
    titleAr: 'حفل منتصف الليل الفاخر',
    subtitleAr: 'ظرف أسود مطفي مع شريط ساتان ذهبي وخطوط ذهبية أنيقة',
    names: ['آوا و آرش', 'Ava & Arash', 'آفا و آرش'],
    verse: ['شبی برای خاطره‌ساختن', 'AN EVENING TO REMEMBER', 'ليلة لا تُنسى'],
    invitation: [
      'در شبی که برای درخشش و خاطره‌سازی کنار هم جمع می‌شویم، حضور شما افتخار ماست.',
      'Join us for an elegant evening of celebration, music, and unforgettable moments.',
      'يسعدنا حضوركم في أمسية أنيقة مليئة بالموسيقى والذكريات الجميلة.',
    ],
    date: ['شنبه ۱۸ دی ۱۴۰۵ · ساعت ۲۰:۳۰', 'Saturday, January 8 · 8:30 PM', 'السبت ٨ يناير · ٨:٣٠ مساءً'],
    venue: ['تهران، هتل اسپیناس پالاس، سالن اسکای', 'Sky Hall, Espinas Palace, Tehran', 'قاعة سكاي، فندق إسبيناس بالاس، طهران'],
    tags: ['black-tie', 'midnight', 'satin', 'gala', 'luxury'],
    palette: {
      backgroundHex: '#111113', surfaceHex: '#171719', primaryTextHex: '#F8F3E8',
      secondaryTextHex: '#C9C0B2', accentGoldHex: '#D7B879', accentSecondaryHex: '#6E5A3B',
      borderStyle: 'DOUBLE_GOLD',
    },
    envelopeStyle: 'SILK_RIBBON_TIE',
    sceneIds: ['SCENE_1_CLOSED_ENVELOPE', 'SCENE_7_GIFT_BOX_OPENING', 'SCENE_3_FLAP_OPENING', 'SCENE_4_CARD_EMERGING', 'SCENE_9_FINAL_PRESENTATION'],
    monogram: 'A · A', music: 'midnight-piano-nocturne', sfx: 'silk-and-box-reveal',
    duration: 1.15, easing: 'expo.out', price: 69000, priceUsd: 42,
  },
  {
    id: 'tpl_persian_garden_night',
    slug: 'persian-garden-night',
    categorySlug: 'wedding',
    title: 'شب‌نشینی باغ ایرانی (Persian Garden Night)',
    subtitle: 'پاکت ترمه الهام‌گرفته از باغ ایرانی، قاب محرابی و دفترچه چندصفحه‌ای',
    titleEn: 'Persian Garden Night',
    subtitleEn: 'A Persian textile-inspired gate, garden palette, and elegant booklet reveal',
    titleAr: 'ليلة الحديقة الفارسية',
    subtitleAr: 'تصميم مستوحى من نسيج ترمه وحدائق فارس مع كتيب أنيق',
    names: ['ترانه و رادین', 'Taraneh & Radin', 'ترانه و رادين'],
    verse: ['به باغ مهر خوش آمدید', 'WELCOME TO OUR GARDEN OF LOVE', 'أهلاً بكم في حديقة الحب'],
    invitation: [
      'در میان عطر بهارنارنج و نوای موسیقی، مشتاقیم آغاز زندگی مشترکمان را با شما جشن بگیریم.',
      'Beneath the garden lights, we invite you to celebrate the beginning of our life together.',
      'تحت أضواء الحديقة، ندعوكم للاحتفال ببداية حياتنا معاً.',
    ],
    date: ['جمعه ۲۴ اردیبهشت ۱۴۰۶ · ساعت ۱۹:۰۰', 'Friday, May 14 · 7:00 PM', 'الجمعة ١٤ مايو · ٧:٠٠ مساءً'],
    venue: ['اصفهان، باغ تالار چهلستون، باغ مرکزی', 'Chehel Sotoun Garden, Isfahan', 'حديقة چهل ستون، أصفهان'],
    tags: ['persian-garden', 'termeh', 'booklet', 'arch', 'wedding'],
    palette: {
      backgroundHex: '#E7E0D0', surfaceHex: '#173B31', primaryTextHex: '#F7F0DF',
      secondaryTextHex: '#D8D0BC', accentGoldHex: '#C7A45B', accentSecondaryHex: '#55745C',
      borderStyle: 'PERSIAN_ARCH',
    },
    envelopeStyle: 'PERSIAN_TERMEH_ARCH',
    sceneIds: ['SCENE_1_CLOSED_ENVELOPE', 'SCENE_2_WAX_SEAL_BREAKING', 'SCENE_3_FLAP_OPENING', 'SCENE_4_CARD_EMERGING', 'SCENE_5_CARD_UNFOLDING', 'SCENE_8_BOOKLET_PAGE_TURNING', 'SCENE_9_FINAL_PRESENTATION'],
    monogram: 'ت · ر', music: 'setar-garden-evening', sfx: 'wax-termeh-paper',
    duration: 1.25, easing: 'power3.inOut', price: 79000, priceUsd: 49,
  },
  {
    id: 'tpl_botanical_baby_shower',
    slug: 'botanical-baby-shower',
    categorySlug: 'floral-romantic',
    title: 'جشن بهاری نوزاد (Botanical Baby Shower)',
    subtitle: 'کاغذ کالک شیری، دو لنگه گیاهی، روبان سبز مریم‌گلی و کارت لطیف آبرنگی',
    titleEn: 'Botanical Baby Shower',
    subtitleEn: 'Soft vellum gatefold, sage ribbon, and delicate watercolor botanical details',
    titleAr: 'احتفال استقبال المولود',
    subtitleAr: 'ورق شفاف بلون الحليب مع شريط أخضر وتفاصيل نباتية ناعمة',
    names: ['به انتظار کوچولوی ما', 'A Little One Is on the Way', 'ننتظر صغيرنا'],
    verse: ['یک عشق کوچک، یک دنیای بزرگ', 'A LITTLE LOVE, A WHOLE NEW WORLD', 'حب صغير وعالم كبير'],
    invitation: [
      'با شوق فراوان از شما دعوت می‌کنیم در جشن صمیمی استقبال از عضو تازه خانواده کنارمان باشید.',
      'Please join us for a sweet gathering as we celebrate the little one soon to arrive.',
      'ندعوكم لمشاركتنا فرحة استقبال فردنا الصغير في لقاء عائلي دافئ.',
    ],
    date: ['یکشنبه ۱۰ خرداد ۱۴۰۶ · ساعت ۱۷:۰۰', 'Sunday, May 31 · 5:00 PM', 'الأحد ٣١ مايو · ٥:٠٠ مساءً'],
    venue: ['تهران، کافه‌باغ لاله، عمارت نارنج', 'Narenj Pavilion, Laleh Garden, Tehran', 'جناح نارنج، حديقة لاله، طهران'],
    tags: ['baby-shower', 'botanical', 'vellum', 'sage', 'family'],
    palette: {
      backgroundHex: '#F1EEE6', surfaceHex: '#FDFBF6', primaryTextHex: '#4D5B4D',
      secondaryTextHex: '#827D70', accentGoldHex: '#B8A47B', accentSecondaryHex: '#9EAA91',
      borderStyle: 'FLORAL_BOTANICAL',
    },
    envelopeStyle: 'BOTANICAL_VELLUM_GATE',
    sceneIds: ['SCENE_1_CLOSED_ENVELOPE', 'SCENE_3_FLAP_OPENING', 'SCENE_6_PAPER_REVEAL', 'SCENE_4_CARD_EMERGING', 'SCENE_9_FINAL_PRESENTATION'],
    monogram: '♡', music: 'soft-piano-lullaby', sfx: 'vellum-and-leaf',
    duration: 0.95, easing: 'expo.out', price: 39000, priceUsd: 24,
  },
  {
    id: 'tpl_engagement_sapphire',
    slug: 'sapphire-engagement',
    categorySlug: 'emerald-luxury',
    title: 'نامزدی یاقوت کبود (Sapphire Engagement)',
    subtitle: 'پاکت آبی نیمه‌شب با مهر موم برجسته و کارت دولایه با لبه‌های نقره‌ای',
    titleEn: 'Sapphire Engagement',
    subtitleEn: 'Midnight-blue envelope, sculpted seal, and layered silver-edged invitation',
    titleAr: 'خطوبة الياقوت الأزرق',
    subtitleAr: 'ظرف أزرق ليلي مع ختم بارز وبطاقة مزدوجة الحواف الفضية',
    names: ['هلیا و سامیار', 'Helia & Samyar', 'هليا و ساميار'],
    verse: ['آغاز پیوندی از جنس عشق', 'A PROMISE, A BEGINNING', 'وعد وبداية'],
    invitation: [
      'با افتخار از شما دعوت می‌کنیم در جشن نامزدی ما، آغاز فصل تازه‌ای از زندگی‌مان را همراهی کنید.',
      'With joy, we invite you to witness the beginning of our next chapter at our engagement celebration.',
      'بكل فرح ندعوكم لمشاركتنا بداية فصل جديد في حفل خطوبتنا.',
    ],
    date: ['پنجشنبه ۲۷ خرداد ۱۴۰۶ · ساعت ۲۰:۰۰', 'Thursday, June 17 · 8:00 PM', 'الخميس ١٧ يونيو · ٨:٠٠ مساءً'],
    venue: ['تبریز، عمارت ائل‌گلی، تالار آبی', 'Blue Hall, El Goli Pavilion, Tabriz', 'القاعة الزرقاء، جناح إئل غولي، تبريز'],
    tags: ['sapphire', 'engagement', 'silver-foil', 'wax-seal', 'midnight-blue'],
    palette: {
      backgroundHex: '#E9EDF4', surfaceHex: '#101D36', primaryTextHex: '#F4F5F8',
      secondaryTextHex: '#C5D0E0', accentGoldHex: '#B9C7DA', accentSecondaryHex: '#55749D',
      borderStyle: 'MODERN_BOLD',
    },
    envelopeStyle: 'ROYAL_WAX_SEAL',
    sceneIds: ['SCENE_1_CLOSED_ENVELOPE', 'SCENE_2_WAX_SEAL_BREAKING', 'SCENE_3_FLAP_OPENING', 'SCENE_4_CARD_EMERGING', 'SCENE_5_CARD_UNFOLDING', 'SCENE_6_PAPER_REVEAL', 'SCENE_9_FINAL_PRESENTATION'],
    monogram: 'ه · س', music: 'cinematic-cello-romance', sfx: 'wax-crack-silver-paper',
    duration: 1.2, easing: 'power3.inOut', price: 72000, priceUsd: 45,
  },
  {
    id: 'tpl_graduation_booklet',
    slug: 'graduation-booklet',
    categorySlug: 'minimal',
    title: 'جشن فارغ‌التحصیلی (Graduation Booklet)',
    subtitle: 'دعوت‌نامه دفترچه‌ای با جلد پارچه‌ای، بند نشانگر و ورق‌خوردن صفحات',
    titleEn: 'The Graduation Edition',
    subtitleEn: 'A refined keepsake booklet with a fabric cover, ribbon marker, and page-turn reveal',
    titleAr: 'دعوة حفل التخرج',
    subtitleAr: 'كتيب أنيق بغلاف قماشي وشريط فاصل مع حركة تقليب الصفحات',
    names: ['نگار رضایی', 'Negar Rezaei', 'نگار رضائي'],
    verse: ['پایان یک مسیر، آغاز افق‌های تازه', 'ONE CHAPTER ENDS. ANOTHER BEGINS.', 'تنتهي مرحلة وتبدأ آفاق جديدة'],
    invitation: [
      'با شادی و افتخار، شما را به جشن پایان یک مسیر پربار و آغاز فصل تازه‌ای از زندگی دعوت می‌کنم.',
      'Please join me as I celebrate this milestone and the beginning of a new chapter.',
      'يسعدني دعوتكم للاحتفال بهذا الإنجاز وبداية مرحلة جديدة.',
    ],
    date: ['سه‌شنبه ۸ تیر ۱۴۰۶ · ساعت ۱۸:۳۰', 'Tuesday, June 29 · 6:30 PM', 'الثلاثاء ٢٩ يونيو · ٦:٣٠ مساءً'],
    venue: ['تهران، تالار همایش دانشگاه، سالن فارغ‌التحصیلان', 'University Grand Hall, Tehran', 'القاعة الكبرى للجامعة، طهران'],
    tags: ['graduation', 'booklet', 'editorial', 'keepsake', 'page-turn'],
    palette: {
      backgroundHex: '#E8E3DA', surfaceHex: '#F7F3EA', primaryTextHex: '#282A32',
      secondaryTextHex: '#74747A', accentGoldHex: '#A68B5B', accentSecondaryHex: '#4D5D7B',
      borderStyle: 'MINIMAL_HAIRLINE',
    },
    envelopeStyle: 'MODERN_ARCH_POCKET',
    sceneIds: ['SCENE_1_CLOSED_ENVELOPE', 'SCENE_3_FLAP_OPENING', 'SCENE_4_CARD_EMERGING', 'SCENE_5_CARD_UNFOLDING', 'SCENE_8_BOOKLET_PAGE_TURNING', 'SCENE_9_FINAL_PRESENTATION'],
    monogram: 'N · 26', music: 'inspiring-piano-and-strings', sfx: 'book-cover-page-turn',
    duration: 1.1, easing: 'expo.out', price: 49000, priceUsd: 31,
  },
];

function makeTemplate(def: ShowcaseDefinition): ValidatedTemplateSpec {
  const [fa, en, ar] = [0, 1, 2] as const;
  const text = (values: [string, string, string]) => ({
    textFa: values[fa],
    textEn: values[en],
    textAr: values[ar],
  });

  const makeElement = (
    id: string,
    name: string,
    type: 'TEXT' | 'ORNAMENT_FRAME' | 'DIVIDER' | 'BADGE',
    x: number, y: number, width: number, height: number,
    values: [string, string, string],
    fill: string, fontSize: number, fontWeight: 'normal' | 'bold',
    zIndex: number, isLocked = false
  ) => ({
    id, name, type, x, y, width, height, rotation: 0,
    ...text(values),
    fontFamily: 'Vazirmatn',
    fontSize, fontWeight, fill,
    letterSpacing: 0, lineHeight: 1.6, align: 'center' as const,
    opacity: 1, isLocked, zIndex,
  });

  return {
    id: def.id,
    slug: def.slug,
    categorySlug: def.categorySlug,
    tags: def.tags,
    versionNumber: 1,
    status: 'PUBLISHED',
    priceToman: def.price,
    priceUsd: def.priceUsd,
    isFree: false,
    palette: def.palette,
    localizedMeta: {
      fa: {
        title: def.title, subtitle: def.subtitle, openingVerse: def.verse[fa],
        hostsHeadline: def.names[fa], invitationProse: def.invitation[fa],
        dateLabel: def.date[fa], venueLabel: def.venue[fa],
      },
      en: {
        title: def.titleEn, subtitle: def.subtitleEn, openingVerse: def.verse[en],
        hostsHeadline: def.names[en], invitationProse: def.invitation[en],
        dateLabel: def.date[en], venueLabel: def.venue[en],
      },
      ar: {
        title: def.titleAr, subtitle: def.subtitleAr, openingVerse: def.verse[ar],
        hostsHeadline: def.names[ar], invitationProse: def.invitation[ar],
        dateLabel: def.date[ar], venueLabel: def.venue[ar],
      },
    },
    openingSequence: {
      envelopeStyle: def.envelopeStyle,
      durationMultiplier: def.duration,
      easingPreset: def.easing,
      waxSealMonogram: def.monogram,
      waxSealColorHex: def.palette.accentGoldHex,
      enable3dSeal: true,
      enabledSceneIds: def.sceneIds,
    },
    audioConfig: {
      musicTrackSlug: def.music,
      sfxPackSlug: def.sfx,
      volume: 0.78,
      fadeInSeconds: 2,
      fadeOutSeconds: 2.4,
      autoplayOnSealBreak: true,
    },
    canvasWidth: 520,
    canvasHeight: 720,
    elements: [
      makeElement(`${def.id}_frame`, 'قاب اصلی قالب', 'ORNAMENT_FRAME', 28, 28, 464, 664, ['', '', ''], def.palette.accentGoldHex, 12, 'normal', 1, true),
      makeElement(`${def.id}_verse`, 'تیتر آغازین', 'TEXT', 58, 86, 404, 42, def.verse, def.palette.accentGoldHex, 14, 'normal', 2),
      makeElement(`${def.id}_names`, 'نام میزبانان', 'TEXT', 48, 188, 424, 78, def.names, def.palette.primaryTextHex, 32, 'bold', 3),
      makeElement(`${def.id}_divider`, 'جداکننده تزئینی', 'DIVIDER', 130, 285, 260, 24, ['✦  ━━━━━  ✦', '✦  ━━━━━  ✦', '✦  ━━━━━  ✦'], def.palette.accentGoldHex, 16, 'bold', 4, true),
      makeElement(`${def.id}_invitation`, 'متن دعوت', 'TEXT', 65, 330, 390, 105, def.invitation, def.palette.primaryTextHex, 16, 'normal', 5),
      makeElement(`${def.id}_date`, 'تاریخ و ساعت', 'BADGE', 80, 475, 360, 58, def.date, def.palette.accentGoldHex, 15, 'bold', 6),
      makeElement(`${def.id}_venue`, 'مکان مراسم', 'TEXT', 62, 565, 396, 55, def.venue, def.palette.secondaryTextHex, 13, 'normal', 7),
    ],
  };
}

export const SHOWCASE_TEMPLATES: readonly ValidatedTemplateSpec[] = definitions.map(makeTemplate);
