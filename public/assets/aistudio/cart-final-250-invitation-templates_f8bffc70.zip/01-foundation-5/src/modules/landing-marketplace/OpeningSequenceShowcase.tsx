import React from 'react';
import type { ValidatedTemplateSpec, SupportedLocale } from '../template-engine/template-schema';

type OpeningStage = {
  id: string;
  fa: string;
  en: string;
  ar: string;
  detailFa: string;
  detailEn: string;
  detailAr: string;
};

const COMMON: Record<string, OpeningStage> = {
  SCENE_1_CLOSED_ENVELOPE: {
    id: 'SCENE_1_CLOSED_ENVELOPE',
    fa: 'نمای پاکت بسته',
    en: 'Closed envelope',
    ar: 'الظرف المغلق',
    detailFa: 'نمای نزدیک از بافت کاغذ، لبه‌ها و جزئیات اولیه پاکت',
    detailEn: 'A close-up reveals the paper texture, edges, and envelope finish',
    detailAr: 'لقطة قريبة تكشف ملمس الورق وحواف الظرف',
  },
  SCENE_2_WAX_SEAL_BREAKING: {
    id: 'SCENE_2_WAX_SEAL_BREAKING',
    fa: 'شکستن مهر موم',
    en: 'Wax seal release',
    ar: 'فتح ختم الشمع',
    detailFa: 'مهر برجسته با یک حرکت ظریف آزاد می‌شود و صدای موم پخش می‌شود',
    detailEn: 'The embossed seal releases with a subtle wax-crack sound',
    detailAr: 'يتحرر الختم البارز مع مؤثر صوتي رقيق',
  },
  SCENE_3_FLAP_OPENING: {
    id: 'SCENE_3_FLAP_OPENING',
    fa: 'باز شدن درِ پاکت',
    en: 'Envelope flap opens',
    ar: 'فتح غطاء الظرف',
    detailFa: 'لبه پاکت با چرخش نرم و سایه طبیعی باز می‌شود',
    detailEn: 'The envelope flap rotates open with natural depth and shadow',
    detailAr: 'يفتح غطاء الظرف بحركة ناعمة وظلال طبيعية',
  },
  SCENE_4_CARD_EMERGING: {
    id: 'SCENE_4_CARD_EMERGING',
    fa: 'خارج شدن کارت',
    en: 'Card emerges',
    ar: 'ظهور البطاقة',
    detailFa: 'کارت از داخل پاکت بالا می‌آید و مرکز قاب قرار می‌گیرد',
    detailEn: 'The invitation slides upward and settles into the center',
    detailAr: 'تنزلق البطاقة إلى الأعلى وتستقر في المنتصف',
  },
  SCENE_5_CARD_UNFOLDING: {
    id: 'SCENE_5_CARD_UNFOLDING',
    fa: 'باز شدن کارت تاشو',
    en: 'Card unfolds',
    ar: 'فتح البطاقة المطوية',
    detailFa: 'دو لت کارت با حرکت هماهنگ باز می‌شوند و سطح داخلی نمایان می‌شود',
    detailEn: 'The folded panels open in sequence to reveal the inside surface',
    detailAr: 'تنفتح أجزاء البطاقة بالتتابع لتكشف الداخل',
  },
  SCENE_6_PAPER_REVEAL: {
    id: 'SCENE_6_PAPER_REVEAL',
    fa: 'نمایان شدن کاغذ داخلی',
    en: 'Inner paper reveal',
    ar: 'ظهور الورق الداخلي',
    detailFa: 'لایه کالک یا کاغذ داخلی کنار می‌رود و متن دعوت دیده می‌شود',
    detailEn: 'The vellum or inner sheet lifts to reveal the invitation copy',
    detailAr: 'ترتفع طبقة الورق الشفاف لتكشف نص الدعوة',
  },
  SCENE_7_GIFT_BOX_OPENING: {
    id: 'SCENE_7_GIFT_BOX_OPENING',
    fa: 'باز شدن جعبه هدیه',
    en: 'Gift box opens',
    ar: 'فتح صندوق الهدية',
    detailFa: 'روبان از دور جعبه باز می‌شود و درِ جعبه بالا می‌رود',
    detailEn: 'The ribbon loosens and the presentation box lid lifts',
    detailAr: 'ينفك الشريط ويرتفع غطاء صندوق التقديم',
  },
  SCENE_8_BOOKLET_PAGE_TURNING: {
    id: 'SCENE_8_BOOKLET_PAGE_TURNING',
    fa: 'ورق خوردن دفترچه',
    en: 'Booklet page turn',
    ar: 'تقليب صفحات الكتيب',
    detailFa: 'صفحه‌ها با خمیدگی کاغذ و سایه طبیعی یکی‌یکی ورق می‌خورند',
    detailEn: 'Pages turn one by one with paper curvature and soft shadows',
    detailAr: 'تتقلب الصفحات واحدة تلو الأخرى مع انحناء وظلال واقعية',
  },
  SCENE_9_FINAL_PRESENTATION: {
    id: 'SCENE_9_FINAL_PRESENTATION',
    fa: 'نمای نهایی دعوت‌نامه',
    en: 'Final invitation reveal',
    ar: 'العرض النهائي للدعوة',
    detailFa: 'کارت کامل، خوانا و در مرکز قاب نمایش داده می‌شود',
    detailEn: 'The complete invitation settles into a clean, readable final view',
    detailAr: 'تستقر الدعوة كاملة في عرض نهائي واضح',
  },
};

export const getOpeningStages = (template: ValidatedTemplateSpec): OpeningStage[] =>
  template.openingSequence.enabledSceneIds
    .map((id) => COMMON[id])
    .filter((stage): stage is OpeningStage => Boolean(stage));

export const OpeningSequenceShowcase: React.FC<{
  template: ValidatedTemplateSpec;
  locale?: SupportedLocale;
}> = ({ template, locale = 'fa' }) => {
  const stages = getOpeningStages(template);
  const isRtl = locale !== 'en';
  const title = locale === 'fa' ? 'سناریوی باز شدن کارت' : locale === 'ar' ? 'مراحل فتح الدعوة' : 'Invitation opening sequence';

  return (
    <section dir={isRtl ? 'rtl' : 'ltr'} className="rounded-2xl border border-[#C5A059]/25 bg-black/25 p-4">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h4 className="text-sm font-extrabold text-[#D8BD86]">{title}</h4>
        <span className="rounded-full border border-[#C5A059]/30 px-2.5 py-1 text-[10px] text-[#EAE3D5]/70">
          {stages.length} {locale === 'fa' ? 'مرحله' : locale === 'ar' ? 'مراحل' : 'steps'}
        </span>
      </div>
      <ol className="space-y-3">
        {stages.map((stage, index) => {
          const label = locale === 'fa' ? stage.fa : locale === 'ar' ? stage.ar : stage.en;
          const detail = locale === 'fa' ? stage.detailFa : locale === 'ar' ? stage.detailAr : stage.detailEn;
          return (
            <li key={stage.id} className="flex items-start gap-3">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#C5A059]/50 bg-[#C5A059]/10 text-[11px] font-black text-[#D8BD86]">
                {index + 1}
              </span>
              <div className="min-w-0 flex-1 border-b border-white/10 pb-3">
                <p className="text-xs font-bold text-[#F8F3E8]">{label}</p>
                <p className="mt-1 text-[11px] leading-6 text-[#EAE3D5]/60">{detail}</p>
              </div>
            </li>
          );
        })}
      </ol>
    </section>
  );
};
