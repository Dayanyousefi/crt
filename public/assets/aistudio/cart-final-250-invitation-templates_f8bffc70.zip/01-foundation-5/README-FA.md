# INVITÉ — Showcase invitation templates and opening storyboards

This add-on pack adds five additional invitation designs to the existing five-template catalog, and exposes a readable opening storyboard in the template detail modal.

## Added showcase designs

1. Black Tie Midnight Gala — matte black, champagne satin ribbon, gift-box opening.
2. Persian Garden Night — Persian textile / termeh-inspired envelope and booklet page turn.
3. Botanical Baby Shower — translucent vellum gatefold and sage ribbon.
4. Sapphire Engagement — midnight-blue wax-sealed envelope and layered card reveal.
5. Graduation Booklet — fabric-cover booklet and page-turn reveal.

Every added template includes Persian, English, and Arabic copy, editable canvas elements, a distinct palette, audio configuration, envelope style, and a curated list of cinematic scene IDs.

## Files

- `src/modules/template-engine/showcase-templates.ts`
- `src/modules/landing-marketplace/OpeningSequenceShowcase.tsx`
- `apply-marketplace-update.mjs` — applies the marketplace integration without replacing the whole component.
- `marketplace-integration.patch` — optional manual patch reference.

## Apply

1. Copy the two TypeScript files into the matching paths in the repository.
2. From the repository root, run `node apply-marketplace-update.mjs` to safely update the existing marketplace component.
3. Run `npm run typecheck`, `npm test`, and `npm run build`.

The patch extends the marketplace list from 5 to 10 designs and inserts the opening storyboard into the existing detail modal. It preserves the existing studio and cinematic callbacks.

## Important

This adds real template records and a UI storyboard for their opening steps. The scene IDs configure the existing cinematic callback, but this pack does not claim to implement new 3D/GSAP scene animations. Those need to be verified in the cinematic engine separately.
