import fs from 'node:fs';
import path from 'node:path';

const target = path.resolve(
  'src/modules/landing-marketplace/LuxuryLandingAndMarketplace.tsx'
);
let source = fs.readFileSync(target, 'utf8');

const importAnchor = "import { TemplateSchemaRenderer } from '../template-engine/TemplateSchemaRenderer';";
if (!source.includes(importAnchor)) {
  throw new Error('Could not find the expected TemplateSchemaRenderer import. No files changed.');
}
if (!source.includes("import { SHOWCASE_TEMPLATES }")) {
  source = source.replace(
    importAnchor,
    [
      "import { TemplateSchemaRenderer } from '../template-engine/TemplateSchemaRenderer';",
      "import { SHOWCASE_TEMPLATES } from '../template-engine/showcase-templates';",
      "import { OpeningSequenceShowcase } from './OpeningSequenceShowcase';",
      '',
      'const MARKETPLACE_TEMPLATES = [...INITIAL_MASTER_TEMPLATES, ...SHOWCASE_TEMPLATES];',
    ].join('\n')
  );
}

const expectedFilter = 'const filteredTemplates = INITIAL_MASTER_TEMPLATES.filter((tpl) => {';
if (source.includes(expectedFilter)) {
  source = source.replace(expectedFilter, 'const filteredTemplates = MARKETPLACE_TEMPLATES.filter((tpl) => {');
} else if (!source.includes('const filteredTemplates = MARKETPLACE_TEMPLATES.filter((tpl) => {')) {
  throw new Error('Could not locate the marketplace filter. No marketplace file was written.');
}

source = source
  .replace('مارکت‌پلیس قالب‌های دعوت‌نامه دیجیتال (۵ معماری متمایز)', 'مارکت‌پلیس قالب‌های دعوت‌نامه دیجیتال (۱۰ طراحی متمایز)')
  .replace("label: 'همه سبک‌ها (۵)'", "label: 'همه سبک‌ها (۱۰)'");

const detailsAnchor = "                <div className=\"flex gap-2 pt-2\">";
if (!source.includes('<OpeningSequenceShowcase template={activeModalTemplate} locale={locale} />')) {
  if (!source.includes(detailsAnchor)) {
    throw new Error('Could not locate the details modal action row. No marketplace file was written.');
  }
  source = source.replace(
    detailsAnchor,
    '                <OpeningSequenceShowcase template={activeModalTemplate} locale={locale} />\n' + detailsAnchor
  );
}

fs.writeFileSync(target, source, 'utf8');
console.log('Marketplace now includes 10 templates and an opening storyboard in the details modal.');
