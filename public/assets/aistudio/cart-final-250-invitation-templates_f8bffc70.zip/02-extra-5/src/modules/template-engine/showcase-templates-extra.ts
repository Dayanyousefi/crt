import type { ValidatedTemplateSpec } from './template-schema';
import { SHOWCASE_TEMPLATES } from './showcase-templates';

type LocaleTriple = [string, string, string];
type Extra = {
  id: string; slug: string; categorySlug: ValidatedTemplateSpec['categorySlug'];
  title: LocaleTriple; subtitle: LocaleTriple; names: LocaleTriple;
  verse: LocaleTriple; invitation: LocaleTriple; date: LocaleTriple; venue: LocaleTriple;
  tags: string[]; palette: ValidatedTemplateSpec['palette'];
  envelopeStyle: ValidatedTemplateSpec['openingSequence']['envelopeStyle'];
  sceneIds: string[]; monogram: string; music: string; sfx: string;
  duration: number; easing: ValidatedTemplateSpec['openingSequence']['easingPreset'];
  price: number; usd: number;
};

const extra: Extra[] = [
  {
    id:'tpl_venetian_royal', slug:'venetian-royal', categorySlug:'emerald-luxury',
    title:['شب نقاب‌های ونیزی','Venetian Royal Masquerade','ليلة الأقنعة الملكية'],
    subtitle:['پاکت زرشکی مخملی، ماسک برجسته و روبان طلایی','Velvet burgundy presentation, sculpted mask seal, and gold edges','ظرف مخملي نبيذي مع ختم قناع وحواف ذهبية'],
    names:['آناهیتا و کیان','Anahita & Kian','آناهیتا وكيان'],
    verse:['شبی فراتر از رویا','AN EVENING BEYOND DREAMS','ليلة تتجاوز الأحلام'],
    invitation:['در شبی رازآلود و باشکوه، مشتاق دیدار شما برای جشن پیوند و شادی‌مان هستیم.','Join us for an enchanting masquerade evening filled with elegance and celebration.','ندعوكم إلى أمسية ساحرة من الأناقة والاحتفال.'],
    date:['پنجشنبه ۱۶ مهر ۱۴۰۶ · ساعت ۲۰:۰۰','Thursday, October 8 · 8:00 PM','الخميس ٨ أكتوبر · ٨:٠٠ مساءً'],
    venue:['تهران، عمارت مسعودیه، تالار آینه','Mirror Hall, Masoudieh Mansion, Tehran','قاعة المرايا، قصر مسعودية، طهران'],
    tags:['venetian','masquerade','velvet','burgundy','royal'],
    palette:{backgroundHex:'#24151D',surfaceHex:'#421F2C',primaryTextHex:'#F7EBDD',secondaryTextHex:'#D9C5B6',accentGoldHex:'#D1AD70',accentSecondaryHex:'#81513F',borderStyle:'DOUBLE_GOLD'},
    envelopeStyle:'SILK_RIBBON_TIE',
    sceneIds:['SCENE_1_CLOSED_ENVELOPE','SCENE_7_GIFT_BOX_OPENING','SCENE_2_WAX_SEAL_BREAKING','SCENE_3_FLAP_OPENING','SCENE_4_CARD_EMERGING','SCENE_9_FINAL_PRESENTATION'],
    monogram:'A · K',music:'venetian-chamber-waltz',sfx:'velvet-box-wax-seal',duration:1.3,easing:'power3.inOut',price:89000,usd:55
  },
  {
    id:'tpl_sakura_spring', slug:'sakura-spring', categorySlug:'floral-romantic',
    title:['بهار ساکورا','Sakura Spring Invitation','دعوة ربيع الساكورا'],
    subtitle:['پاکت صورتی پودری، کاغذ دست‌ساز و شکوفه‌های برجسته','Powder-pink handmade paper and delicate blossoms','ورق وردي ناعم مع أزهار الكرز'],
    names:['رها و ماهان','Raha & Mahan','رها وماهان'],
    verse:['عشق، چون شکوفه‌ای تازه','LOVE IN FULL BLOOM','الحب في أبهى تفتح'],
    invitation:['همراه با شکفتن بهار، از شما دعوت می‌کنیم در زیباترین آغاز زندگی‌مان کنار ما باشید.','As spring blossoms, join us to celebrate the beginning of our life together.','مع تفتح الربيع، ندعوكم للاحتفال ببداية حياتنا معاً.'],
    date:['جمعه ۲۱ اسفند ۱۴۰۶ · ساعت ۱۸:۰۰','Friday, March 12 · 6:00 PM','الجمعة ١٢ مارس · ٦:٠٠ مساءً'],
    venue:['شیراز، باغ ارم، عمارت بهار','Bahār Pavilion, Eram Garden, Shiraz','جناح بهار، حديقة إرم، شيراز'],
    tags:['sakura','spring','cherry-blossom','pink','gatefold'],
    palette:{backgroundHex:'#F5E9E6',surfaceHex:'#FFF9F5',primaryTextHex:'#634A4D',secondaryTextHex:'#967C7D',accentGoldHex:'#C7A18D',accentSecondaryHex:'#D9AEB5',borderStyle:'FLORAL_BOTANICAL'},
    envelopeStyle:'BOTANICAL_VELLUM_GATE',
    sceneIds:['SCENE_1_CLOSED_ENVELOPE','SCENE_3_FLAP_OPENING','SCENE_6_PAPER_REVEAL','SCENE_5_CARD_UNFOLDING','SCENE_4_CARD_EMERGING','SCENE_9_FINAL_PRESENTATION'],
    monogram:'桜',music:'sakura-piano-and-koto',sfx:'soft-paper-petal-fall',duration:1.05,easing:'expo.out',price:59000,usd:36
  },
  {
    id:'tpl_art_deco_1920', slug:'art-deco-1920', categorySlug:'minimal',
    title:['آرت‌دکو ۱۹۲۰','The Art Deco Edition','تصميم آرت ديكو'],
    subtitle:['هندسه طلایی، پاکت ذغالی و خطوط معماری','Geometric gold foil, charcoal envelope, architectural fan motifs','زخارف هندسية ذهبية وظرف فحمي'],
    names:['آرتمیس و بردیا','Artemis & Bardia','آرتميس وبرديا'],
    verse:['ظرافت، در هر جزئیات','ELEGANCE IN EVERY DETAIL','الأناقة في كل تفصيل'],
    invitation:['با افتخار شما را به شبی باشکوه دعوت می‌کنیم؛ شبی برای جشن گرفتن یک آغاز تازه.','Join us for a glamorous evening celebrating a new beginning in timeless style.','ندعوكم إلى أمسية فاخرة للاحتفال ببداية جديدة بأسلوب خالد.'],
    date:['شنبه ۲۲ آبان ۱۴۰۶ · ساعت ۲۰:۳۰','Saturday, November 13 · 8:30 PM','السبت ١٣ نوفمبر · ٨:٣٠ مساءً'],
    venue:['تهران، هتل پارسیان آزادی، سالن زرین','Zarrin Ballroom, Parsian Azadi Hotel, Tehran','قاعة زرین، فندق بارسيان آزادي، طهران'],
    tags:['art-deco','1920s','geometric','charcoal','gold-foil'],
    palette:{backgroundHex:'#17191B',surfaceHex:'#202326',primaryTextHex:'#F4EBDD',secondaryTextHex:'#C8C0B3',accentGoldHex:'#D0AE69',accentSecondaryHex:'#7C6846',borderStyle:'GEOMETRIC_GOLD'},
    envelopeStyle:'MODERN_ARCH_POCKET',
    sceneIds:['SCENE_1_CLOSED_ENVELOPE','SCENE_2_WAX_SEAL_BREAKING','SCENE_3_FLAP_OPENING','SCENE_4_CARD_EMERGING','SCENE_5_CARD_UNFOLDING','SCENE_9_FINAL_PRESENTATION'],
    monogram:'A · B',music:'art-deco-jazz-piano',sfx:'geometric-card-slide',duration:1.15,easing:'power3.inOut',price:76000,usd:47
  },
  {
    id:'tpl_celestial_milestone', slug:'celestial-milestone', categorySlug:'minimal',
    title:['زیر آسمان ستاره‌ها','A Celestial Celebration','احتفال تحت النجوم'],
    subtitle:['پاکت سرمه‌ای کهکشانی، نقشه فلکی و درخشش ستاره‌ای','Midnight-blue constellation envelope and star-lit reveal','ظرف أزرق ليلي بخريطة كوكبية وبطاقة متلألئة'],
    names:['جشن تولد آدرین','Adrian’s Birthday','عيد ميلاد أدريان'],
    verse:['یک شب، هزار ستاره','ONE NIGHT. A THOUSAND STARS.','ليلة وألف نجمة'],
    invitation:['زیر آسمانی پر از ستاره، منتظریم تا یک شب فراموش‌نشدنی را در کنار شما بسازیم.','Under a sky full of stars, join us for a night made for unforgettable memories.','تحت سماء مليئة بالنجوم، ننتظركم لقضاء ليلة لا تُنسى.'],
    date:['جمعه ۵ آذر ۱۴۰۶ · ساعت ۱۹:۳۰','Friday, November 26 · 7:30 PM','الجمعة ٢٦ نوفمبر · ٧:٣٠ مساءً'],
    venue:['تهران، روف‌گاردن آسمان، طبقه ۲۱','Aseman Rooftop, 21st Floor, Tehran','روف آسمان، الطابق ٢١، طهران'],
    tags:['celestial','stars','birthday','constellation','midnight'],
    palette:{backgroundHex:'#0D1830',surfaceHex:'#152747',primaryTextHex:'#F3F1E8',secondaryTextHex:'#B9C7DE',accentGoldHex:'#D8C58E',accentSecondaryHex:'#7798C7',borderStyle:'STAR_MAP'},
    envelopeStyle:'ROYAL_WAX_SEAL',
    sceneIds:['SCENE_1_CLOSED_ENVELOPE','SCENE_2_WAX_SEAL_BREAKING','SCENE_3_FLAP_OPENING','SCENE_6_PAPER_REVEAL','SCENE_4_CARD_EMERGING','SCENE_9_FINAL_PRESENTATION'],
    monogram:'✦',music:'celestial-ambient-piano',sfx:'stardust-wax-reveal',duration:1.35,easing:'expo.out',price:45000,usd:28
  },
  {
    id:'tpl_luxe_brand_launch', slug:'luxe-brand-launch', categorySlug:'emerald-luxury',
    title:['رونمایی اختصاصی برند','The Luxe Brand Launch','إطلاق العلامة الفاخرة'],
    subtitle:['جعبه مشکی مینیمال، پلاک فلزی و کشوی مخفی','Minimal black presentation box, metal brand plate, hidden drawer','صندوق أسود بسيط مع لوحة معدنية ودرج مخفي'],
    names:['رونمایی مجموعه جدید','The New Collection','إطلاق المجموعة الجديدة'],
    verse:['دعوتی فراتر از انتظار','AN INVITATION BEYOND EXPECTATION','دعوة تتجاوز التوقعات'],
    invitation:['مفتخریم شما را به معرفی اختصاصی مجموعه جدید دعوت کنیم؛ تجربه‌ای ویژه برای مهمانان منتخب.','You are invited to an exclusive first look at our new collection, reserved for our distinguished guests.','ندعوكم إلى عرض حصري أول للمجموعة الجديدة لضيوفنا المميزين.'],
    date:['چهارشنبه ۱۲ آذر ۱۴۰۶ · ساعت ۱۹:۰۰','Wednesday, December 3 · 7:00 PM','الأربعاء ٣ ديسمبر · ٧:٠٠ مساءً'],
    venue:['تهران، مرکز همایش‌های بین‌المللی، گالری VIP','VIP Gallery, International Convention Center, Tehran','قاعة كبار الزوار، مركز المؤتمرات الدولي، طهران'],
    tags:['brand-launch','corporate','drawer-box','minimal','vip'],
    palette:{backgroundHex:'#111214',surfaceHex:'#202124',primaryTextHex:'#F5F2EB',secondaryTextHex:'#BFC0C0',accentGoldHex:'#B8A06A',accentSecondaryHex:'#74716B',borderStyle:'MINIMAL_HAIRLINE'},
    envelopeStyle:'SILK_RIBBON_TIE',
    sceneIds:['SCENE_1_CLOSED_ENVELOPE','SCENE_7_GIFT_BOX_OPENING','SCENE_3_FLAP_OPENING','SCENE_4_CARD_EMERGING','SCENE_6_PAPER_REVEAL','SCENE_9_FINAL_PRESENTATION'],
    monogram:'LUXE',music:'modern-luxury-brand-score',sfx:'magnetic-box-drawer-reveal',duration:1.4,easing:'power3.inOut',price:99000,usd:62
  }
];

const build = (d: Extra): ValidatedTemplateSpec => {
  const localizedMeta = (i: number) => ({
    title:d.title[i], subtitle:d.subtitle[i], openingVerse:d.verse[i],
    hostsHeadline:d.names[i], invitationProse:d.invitation[i],
    dateLabel:d.date[i], venueLabel:d.venue[i],
  });
  const el = (id:string,name:string,type:'TEXT'|'ORNAMENT_FRAME'|'DIVIDER'|'BADGE',
    x:number,y:number,width:number,height:number,values:LocaleTriple,fill:string,fontSize:number,
    fontWeight:'normal'|'bold',zIndex:number,isLocked=false) => ({
      id,name,type,x,y,width,height,rotation:0,textFa:values[0],textEn:values[1],textAr:values[2],
      fontFamily:'Vazirmatn',fontSize,fontWeight,fill,letterSpacing:0,lineHeight:1.6,
      align:'center' as const,opacity:1,isLocked,zIndex,
    });
  return {
    id:d.id,slug:d.slug,categorySlug:d.categorySlug,tags:d.tags,versionNumber:1,status:'PUBLISHED',
    priceToman:d.price,priceUsd:d.usd,isFree:false,palette:d.palette,
    localizedMeta:{fa:localizedMeta(0),en:localizedMeta(1),ar:localizedMeta(2)},
    openingSequence:{envelopeStyle:d.envelopeStyle,durationMultiplier:d.duration,easingPreset:d.easing,
      waxSealMonogram:d.monogram,waxSealColorHex:d.palette.accentGoldHex,enable3dSeal:true,enabledSceneIds:d.sceneIds},
    audioConfig:{musicTrackSlug:d.music,sfxPackSlug:d.sfx,volume:0.78,fadeInSeconds:2,fadeOutSeconds:2.4,autoplayOnSealBreak:true},
    canvasWidth:520,canvasHeight:720,
    elements:[
      el(d.id+'_frame','قاب اصلی قالب','ORNAMENT_FRAME',28,28,464,664,['','',''],d.palette.accentGoldHex,12,'normal',1,true),
      el(d.id+'_verse','تیتر آغازین','TEXT',58,86,404,42,d.verse,d.palette.accentGoldHex,14,'normal',2),
      el(d.id+'_names','نام میزبانان','TEXT',48,188,424,78,d.names,d.palette.primaryTextHex,32,'bold',3),
      el(d.id+'_divider','جداکننده تزئینی','DIVIDER',130,285,260,24,['✦ ━━━━━ ✦','✦ ━━━━━ ✦','✦ ━━━━━ ✦'],d.palette.accentGoldHex,16,'bold',4,true),
      el(d.id+'_invitation','متن دعوت','TEXT',65,330,390,105,d.invitation,d.palette.primaryTextHex,16,'normal',5),
      el(d.id+'_date','تاریخ و ساعت','BADGE',80,475,360,58,d.date,d.palette.accentGoldHex,15,'bold',6),
      el(d.id+'_venue','مکان مراسم','TEXT',62,565,396,55,d.venue,d.palette.secondaryTextHex,13,'normal',7),
    ],
  };
};

export const EXTRA_SHOWCASE_TEMPLATES: readonly ValidatedTemplateSpec[] = extra.map(build);
export const ALL_SHOWCASE_TEMPLATES: readonly ValidatedTemplateSpec[] = [
  ...SHOWCASE_TEMPLATES, ...EXTRA_SHOWCASE_TEMPLATES,
];
