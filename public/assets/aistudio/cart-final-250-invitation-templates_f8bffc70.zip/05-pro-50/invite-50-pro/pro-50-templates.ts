export type ProOpeningStage = {
  step: number;
  scene: string;
  title: string;
  description: string;
  duration_ms: number;
};

export type ProShowcaseTemplate = {
  id: string;
  slug: string;
  name: { fa: string; en: string };
  category: string;
  category_label: string;
  art_direction: string;
  palette: { base: string; accent: string };
  opening_sequence: ProOpeningStage[];
  editor_fields: string[];
  interaction: { desktop: string[]; mobile: string[]; skip_available: boolean; replay_available: boolean };
  accessibility: { reduced_motion: string; audio_default: string; keyboard_navigation: boolean };
  rendering: { aspect_ratio: string; mobile_first: boolean; rtl_ready: boolean; scene_based: boolean };
};

export const PRO_SHOWCASE_TEMPLATES_50: ProShowcaseTemplate[] = [
  {
    "id": "pro-showcase-001",
    "slug": "wedding-001-palace-of-mirrors",
    "name": {
      "fa": "کاخ آینه",
      "en": "Palace of Mirrors"
    },
    "category": "wedding",
    "category_label": "عروسی",
    "art_direction": "کارت از پشت دو در آینه‌ای بیرون می‌آید؛ انعکاس‌ها با بازشدن درها محو می‌شوند.",
    "palette": {
      "base": "ivory",
      "accent": "champagne"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "دو در آینه‌ای با لولا باز می‌شوند",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "انعکاس‌ها به خطوط نور تبدیل می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "کارت با عمق سه‌لایه بیرون می‌آید",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "قاب طلایی دور کارت کامل می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با جزئیات مراسم",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-002",
    "slug": "wedding-002-orchid-conservatory",
    "name": {
      "fa": "باغ ارکیده",
      "en": "Orchid Conservatory"
    },
    "category": "wedding",
    "category_label": "عروسی",
    "art_direction": "گل‌های ارکیده از غنچه به شکوفه می‌رسند و پنجره شیشه‌ای گلخانه باز می‌شود.",
    "palette": {
      "base": "sage",
      "accent": "pearl"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "قطرات شبنم روی شیشه ظاهر می‌شوند",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "پنل‌های گلخانه به طرفین می‌لغزند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "غنچه‌ها باز می‌شوند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از میان برگ‌ها بالا می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی در قاب گیاهی",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-003",
    "slug": "wedding-003-silk-envelope",
    "name": {
      "fa": "پاکت پارچه‌ای",
      "en": "Silk Envelope"
    },
    "category": "wedding",
    "category_label": "عروسی",
    "art_direction": "پارچه ابریشمی دور کارت باز می‌شود؛ چین‌ها واقعی و نرم حرکت می‌کنند.",
    "palette": {
      "base": "plum",
      "accent": "rose-gold"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "گره ابریشمی آزاد می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "پارچه با حرکت موجی کنار می‌رود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "لبه کارت از زیر پارچه نمایان می‌شود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت بالا می‌آید و صاف می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی روی بافت ابریشم",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-004",
    "slug": "wedding-004-gothic-arch",
    "name": {
      "fa": "کلیسای گوتیک",
      "en": "Gothic Arch"
    },
    "category": "wedding",
    "category_label": "عروسی",
    "art_direction": "طاق‌های معماری به ترتیب باز می‌شوند و نور از پنجره رنگی روی کارت می‌افتد.",
    "palette": {
      "base": "charcoal",
      "accent": "antique-gold"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "دروازه سنگی در قاب باز می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "پنجره شیشه‌رنگی روشن می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "پرتو نور روی کاغذ حرکت می‌کند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از عمق محراب بیرون می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با قاب معماری",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-005",
    "slug": "wedding-005-gold-emboss",
    "name": {
      "fa": "نقش برجسته طلاکوب",
      "en": "Gold Emboss"
    },
    "category": "wedding",
    "category_label": "عروسی",
    "art_direction": "نقش برجسته روی کاغذ از دل بافت ظاهر می‌شود و کارت با برش دقیق از قاب جدا می‌شود.",
    "palette": {
      "base": "cream",
      "accent": "gold"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "مهر برجسته از مرکز بلند می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "نقوش طلاکوب از حاشیه تا مرکز روشن می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "خط برش کارت آشکار می‌شود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از قاب جدا و باز می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با بافت چاپ",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-006",
    "slug": "wedding-006-moon-window",
    "name": {
      "fa": "پنجره ماه",
      "en": "Moon Window"
    },
    "category": "wedding",
    "category_label": "عروسی",
    "art_direction": "هلال ماه روی پنجره حرکت می‌کند؛ پنجره باز و کارت زیر آسمان ستاره‌ای نمایان می‌شود.",
    "palette": {
      "base": "midnight",
      "accent": "silver"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "هلال در آسمان حرکت می‌کند",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "دو لنگه پنجره باز می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "ستاره‌ها به اطراف پراکنده می‌شوند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از پشت پنجره می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با نور ماه",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-007",
    "slug": "wedding-007-blooming-keepsake",
    "name": {
      "fa": "جعبه گل‌دار",
      "en": "Blooming Keepsake"
    },
    "category": "wedding",
    "category_label": "عروسی",
    "art_direction": "جعبه با چهار بال باز می‌شود؛ هر بال یک لایه گل و متن را آشکار می‌کند.",
    "palette": {
      "base": "blush",
      "accent": "copper"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "قفل کوچک آزاد می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "چهار بال جعبه به ترتیب باز می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "گل‌های کاغذی از مرکز باز می‌شوند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت مرکزی بالا می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی از بالا",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-008",
    "slug": "wedding-008-sculpted-waves",
    "name": {
      "fa": "کارت موج‌دار",
      "en": "Sculpted Waves"
    },
    "category": "wedding",
    "category_label": "عروسی",
    "art_direction": "لایه‌های کاغذ موج‌دار مانند امواج از هم فاصله می‌گیرند و کارت در میان آن‌ها نمایان می‌شود.",
    "palette": {
      "base": "sand",
      "accent": "bronze"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "موج اول از مرکز بلند می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "لایه‌های موجی به طرفین حرکت می‌کنند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "سایه‌های عمقی نمایان می‌شوند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از میان موج‌ها بیرون می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با لبه‌های موج‌دار",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-009",
    "slug": "wedding-009-vow-journal",
    "name": {
      "fa": "دفتر عهد",
      "en": "Vow Journal"
    },
    "category": "wedding",
    "category_label": "عروسی",
    "art_direction": "جلد چرمی باز می‌شود؛ بند چرمی آزاد و صفحات با ورق‌زدن واقعی به دعوت می‌رسند.",
    "palette": {
      "base": "oxblood",
      "accent": "brass"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "بند چرمی از جلد باز می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "جلد به‌آرامی باز می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "دو صفحه ورق می‌خورند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "صفحه دعوت با مکث باز می‌ماند",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی شبیه دفتر چاپی",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-010",
    "slug": "wedding-010-glass-atelier",
    "name": {
      "fa": "قاب شیشه‌ای",
      "en": "Glass Atelier"
    },
    "category": "wedding",
    "category_label": "عروسی",
    "art_direction": "صفحات شیشه‌ای مات روی هم قرار دارند؛ هر صفحه کنار می‌رود تا کارت زیرین واضح شود.",
    "palette": {
      "base": "smoke",
      "accent": "platinum"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "شیشه مات از بخار پاک می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "سه پنل شیشه‌ای در عمق جابه‌جا می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "لبه‌های منشوری نور می‌گیرند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت زیرین به جلو می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی شفاف و مینیمال",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-011",
    "slug": "engagement-011-hidden-ring-box",
    "name": {
      "fa": "جعبه حلقه مخفی",
      "en": "Hidden Ring Box"
    },
    "category": "engagement",
    "category_label": "نامزدی",
    "art_direction": "جعبه انگشتر با حرکت مکانیکی باز می‌شود؛ پایه داخلی بالا می‌آید و کارت در پشت آن می‌چرخد.",
    "palette": {
      "base": "navy",
      "accent": "silver"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "قفل جعبه با چرخش باز می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "در مخملی بالا می‌رود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "پایه حلقه از داخل بالا می‌آید",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت پشت پایه می‌چرخد و روبه‌رو می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با حلقه و متن",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-012",
    "slug": "engagement-012-two-halves",
    "name": {
      "fa": "دو نیمه یک قلب",
      "en": "Two Halves"
    },
    "category": "engagement",
    "category_label": "نامزدی",
    "art_direction": "دو نیمه قلب از هم فاصله می‌گیرند و فضای خالی میان آن‌ها به قاب دعوت تبدیل می‌شود.",
    "palette": {
      "base": "rose",
      "accent": "ruby"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "دو نیمه قلب در مرکز دیده می‌شوند",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "نیمه‌ها به چپ و راست حرکت می‌کنند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "خط نور میان دو نیمه شکل می‌گیرد",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت در فضای مرکزی ظاهر می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با دو نیمه متقارن",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-013",
    "slug": "engagement-013-lock-key",
    "name": {
      "fa": "قفل و کلید",
      "en": "Lock & Key"
    },
    "category": "engagement",
    "category_label": "نامزدی",
    "art_direction": "کلید وارد قفل می‌شود؛ قفل باز و در کوچک روی کارت کنار می‌رود.",
    "palette": {
      "base": "forest",
      "accent": "gold"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "کلید از کناره وارد می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "کلید می‌چرخد و قفل باز می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "در کوچک با لولا حرکت می‌کند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از محفظه بیرون می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با کلید در حاشیه",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-014",
    "slug": "engagement-014-crystal-rose",
    "name": {
      "fa": "گل رز شیشه‌ای",
      "en": "Crystal Rose"
    },
    "category": "engagement",
    "category_label": "نامزدی",
    "art_direction": "گل رز کریستالی از حالت بسته باز می‌شود؛ گلبرگ‌ها به قاب‌های شفاف کارت تبدیل می‌شوند.",
    "palette": {
      "base": "frost",
      "accent": "rose-gold"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "گلبرگ کریستالی بسته می‌درخشد",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "گلبرگ‌ها لایه‌به‌لایه باز می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "قطرات نور در مرکز جمع می‌شوند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از مرکز گل بالا می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با گل باز",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-015",
    "slug": "engagement-015-love-in-frames",
    "name": {
      "fa": "نوار فیلم عاشقانه",
      "en": "Love in Frames"
    },
    "category": "engagement",
    "category_label": "نامزدی",
    "art_direction": "فریم‌های فیلم از مقابل دوربین عبور می‌کنند؛ آخرین فریم به کارت دعوت تمام‌صفحه تبدیل می‌شود.",
    "palette": {
      "base": "black",
      "accent": "champagne"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "نوار فیلم از تاریکی وارد می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "فریم‌ها با سرعت کنترل‌شده عبور می‌کنند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "آخرین فریم مکث می‌کند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "فریم به کارت باز می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با حاشیه سینمایی",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-016",
    "slug": "adult-birthday-016-neon-afterglow",
    "name": {
      "fa": "کلاب نئون",
      "en": "Neon Afterglow"
    },
    "category": "adult-birthday",
    "category_label": "تولد بزرگسال",
    "art_direction": "تابلوی نئون خاموش روشن می‌شود؛ خطوط نور محیط را می‌سازند و کارت از پشت تابلو می‌لغزد.",
    "palette": {
      "base": "black",
      "accent": "electric-blue"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "تابلو خاموش در تاریکی دیده می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "حروف نئون یکی‌یکی روشن می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "نور روی دیوار حرکت می‌کند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "پنل دعوت از پشت تابلو بیرون می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با نور محیط",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-017",
    "slug": "adult-birthday-017-champagne-ritual",
    "name": {
      "fa": "شامپاین و حباب",
      "en": "Champagne Ritual"
    },
    "category": "adult-birthday",
    "category_label": "تولد بزرگسال",
    "art_direction": "حباب‌ها از جام بالا می‌روند؛ جام کنار می‌رود و کارت روی سطح میز آشکار می‌شود.",
    "palette": {
      "base": "champagne",
      "accent": "gold"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "جام کریستال در نور دیده می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "حباب‌ها از پایین به بالا حرکت می‌کنند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "جام با چرخش ظریف کنار می‌رود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت روی میز باز می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با نور طلایی",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-018",
    "slug": "adult-birthday-018-vinyl-session",
    "name": {
      "fa": "صفحه گرامافون",
      "en": "Vinyl Session"
    },
    "category": "adult-birthday",
    "category_label": "تولد بزرگسال",
    "art_direction": "صفحه وینیل می‌چرخد؛ بازوی گرامافون بالا می‌رود و لیبل صفحه به کارت تبدیل می‌شود.",
    "palette": {
      "base": "burgundy",
      "accent": "cream"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "صفحه روی گرامافون قرار می‌گیرد",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "صفحه شروع به چرخش می‌کند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "بازوی گرامافون کنار می‌رود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "دایره مرکزی به کارت مستطیلی گسترش می‌یابد",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با حس موسیقی",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-019",
    "slug": "adult-birthday-019-royal-playing-card",
    "name": {
      "fa": "کارت بازی سلطنتی",
      "en": "Royal Playing Card"
    },
    "category": "adult-birthday",
    "category_label": "تولد بزرگسال",
    "art_direction": "کارت پشت‌ورو می‌شود؛ چند کارت اطراف کنار می‌روند و کارت اصلی در مرکز باز می‌شود.",
    "palette": {
      "base": "ivory",
      "accent": "red"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "دسته کارت روی میز دیده می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "کارت‌ها به شکل بادبزن پخش می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "کارت ویژه به مرکز می‌آید",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت اصلی پشت‌ورو و باز می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با قاب بازی",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-020",
    "slug": "adult-birthday-020-golden-hour-clock",
    "name": {
      "fa": "ساعت طلایی",
      "en": "Golden Hour Clock"
    },
    "category": "adult-birthday",
    "category_label": "تولد بزرگسال",
    "art_direction": "عقربه‌های ساعت به زمان مراسم می‌رسند؛ صفحه ساعت مانند در باز می‌شود و دعوت پدیدار می‌شود.",
    "palette": {
      "base": "bronze",
      "accent": "amber"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "عقربه‌ها از حرکت می‌ایستند",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "حلقه دور صفحه می‌چرخد",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "صفحه ساعت مانند دریچه باز می‌شود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از پشت صفحه جلو می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با زمان برجسته",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-021",
    "slug": "kids-birthday-021-dino-expedition",
    "name": {
      "fa": "ماجراجویی دایناسورها",
      "en": "Dino Expedition"
    },
    "category": "kids-birthday",
    "category_label": "تولد کودک",
    "art_direction": "تخم دایناسور ترک می‌خورد؛ برگ‌ها کنار می‌روند و نقشه جشن روی یک لوح ظاهر می‌شود.",
    "palette": {
      "base": "jungle",
      "accent": "lime"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "تخم در میان برگ‌ها تکان می‌خورد",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "پوسته تخم باز می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "برگ‌های بزرگ به طرفین می‌روند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "لوح دعوت از زمین بالا می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با دایناسور کوچک",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-022",
    "slug": "kids-birthday-022-magic-circus",
    "name": {
      "fa": "سیرک جادویی",
      "en": "Magic Circus"
    },
    "category": "kids-birthday",
    "category_label": "تولد کودک",
    "art_direction": "چادر سیرک باز می‌شود؛ نورافکن‌ها روشن و کارت روی صحنه بالا می‌آید.",
    "palette": {
      "base": "red",
      "accent": "cream"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "چادر بسته و چراغ‌ها خاموش‌اند",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "پرده چادر از مرکز باز می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "نورافکن‌ها مسیر را روشن می‌کنند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت روی سکوی صحنه بالا می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با حاشیه پرچمی",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-023",
    "slug": "kids-birthday-023-undersea-explorer",
    "name": {
      "fa": "زیردریایی کوچک",
      "en": "Undersea Explorer"
    },
    "category": "kids-birthday",
    "category_label": "تولد کودک",
    "art_direction": "دریچه زیردریایی می‌چرخد؛ پنجره آب باز می‌شود و کارت از پشت شیشه بیرون می‌آید.",
    "palette": {
      "base": "ocean",
      "accent": "coral"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "حباب‌ها از دریچه عبور می‌کنند",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "دریچه با چرخش باز می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "پنجره شیشه‌ای به طرفین می‌لغزد",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از عمق آبی نزدیک می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با ماهی‌های کوچک",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-024",
    "slug": "kids-birthday-024-space-station",
    "name": {
      "fa": "ایستگاه فضایی",
      "en": "Space Station"
    },
    "category": "kids-birthday",
    "category_label": "تولد کودک",
    "art_direction": "دریچه سفینه باز می‌شود؛ قطعات شناور کنار می‌روند و کارت در مرکز ایستگاه معلق می‌ماند.",
    "palette": {
      "base": "indigo",
      "accent": "cyan"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "سفینه در نمای دور دیده می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "دریچه به سمت بالا باز می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "قطعات شناور به کناره‌ها می‌روند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت در مرکز معلق و صاف می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با ستاره‌ها",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-025",
    "slug": "kids-birthday-025-enchanted-forest",
    "name": {
      "fa": "جنگل افسانه‌ای",
      "en": "Enchanted Forest"
    },
    "category": "kids-birthday",
    "category_label": "تولد کودک",
    "art_direction": "درختان از هم فاصله می‌گیرند؛ مسیر نورانی شکل می‌گیرد و کتاب دعوت از روی کنده درخت باز می‌شود.",
    "palette": {
      "base": "moss",
      "accent": "butter"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "مه جنگل آرام کنار می‌رود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "دو درخت خم شده و راه باز می‌کنند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "کرم‌های شب‌تاب مسیر را روشن می‌کنند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کتاب روی کنده باز می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با جنگل روشن",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-026",
    "slug": "baby-shower-026-heirloom-album",
    "name": {
      "fa": "آلبوم پارچه‌ای",
      "en": "Heirloom Album"
    },
    "category": "baby-shower",
    "category_label": "جشن نوزاد",
    "art_direction": "جلد پارچه‌ای با بند باز می‌شود؛ صفحات ضخیم آلبوم یکی‌یکی ورق می‌خورند.",
    "palette": {
      "base": "linen",
      "accent": "sage"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "بند پارچه‌ای باز می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "جلد پارچه‌ای بلند می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "صفحات آلبوم ورق می‌خورند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "صفحه دعوت با قاب عکس نمایان می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با حس یادگاری",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-027",
    "slug": "baby-shower-027-sleepy-moon",
    "name": {
      "fa": "ماه خواب‌آلود",
      "en": "Sleepy Moon"
    },
    "category": "baby-shower",
    "category_label": "جشن نوزاد",
    "art_direction": "ماه هلال از پشت ابر بیرون می‌آید؛ ستاره‌ها کنار می‌روند و کارت مانند آویز گهواره پایین می‌آید.",
    "palette": {
      "base": "powder-blue",
      "accent": "silver"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "ابرها روی ماه حرکت می‌کنند",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "ماه از پشت ابر نمایان می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "ستاره‌ها به حاشیه می‌روند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت مانند آویز پایین می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی آرام و لطیف",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-028",
    "slug": "baby-shower-028-little-wardrobe",
    "name": {
      "fa": "کمد کوچک نوزاد",
      "en": "Little Wardrobe"
    },
    "category": "baby-shower",
    "category_label": "جشن نوزاد",
    "art_direction": "دو در کمد کوچک باز می‌شوند؛ لباس‌ها کنار می‌روند و کارت روی چوب‌لباسی نمایان می‌شود.",
    "palette": {
      "base": "buttercream",
      "accent": "mint"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "دستگیره‌ها نزدیک می‌شوند",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "دو در کمد باز می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "لباس‌ها به آرامی کنار می‌روند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت روی چوب‌لباسی می‌چرخد",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با جزئیات پارچه",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-029",
    "slug": "baby-shower-029-balloon",
    "name": {
      "fa": "بادکنک شفاف",
      "en": "透明 Balloon"
    },
    "category": "baby-shower",
    "category_label": "جشن نوزاد",
    "art_direction": "بادکنک شفاف بزرگ می‌شود؛ روبان باز می‌شود و کارت داخل بادکنک به جلو می‌آید.",
    "palette": {
      "base": "clear",
      "accent": "peach"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "بادکنک کوچک در مرکز دیده می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "بادکنک آرام بزرگ می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "روبان از گره آزاد می‌شود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از داخل حباب بیرون می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با حباب‌های کوچک",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-030",
    "slug": "baby-shower-030-music-box",
    "name": {
      "fa": "جعبه موسیقی",
      "en": "Music Box"
    },
    "category": "baby-shower",
    "category_label": "جشن نوزاد",
    "art_direction": "در جعبه موسیقی باز می‌شود؛ صفحه گردان می‌چرخد و کارت از پشت صحنه کوچک بالا می‌آید.",
    "palette": {
      "base": "cream",
      "accent": "lavender"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "در جعبه بسته با نقش ظریف دیده می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "در جعبه باز می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "صفحه گردان شروع به چرخش می‌کند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از پشت صحنه بالا می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با حس موزیکال",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-031",
    "slug": "graduation-031-grand-library",
    "name": {
      "fa": "کتابخانه بزرگ",
      "en": "Grand Library"
    },
    "category": "graduation",
    "category_label": "فارغ‌التحصیلی",
    "art_direction": "قفسه‌های کتاب از مرکز باز می‌شوند؛ یک کتاب بیرون می‌آید و جلدش به کارت تبدیل می‌شود.",
    "palette": {
      "base": "walnut",
      "accent": "brass"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "ردیف کتاب‌ها در قاب دیده می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "قفسه مرکزی کنار می‌رود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "کتاب منتخب بیرون می‌آید",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "جلد کتاب باز و کارت نمایان می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی در کتابخانه",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-032",
    "slug": "graduation-032-medal-of-honor",
    "name": {
      "fa": "مدال افتخار",
      "en": "Medal of Honor"
    },
    "category": "graduation",
    "category_label": "فارغ‌التحصیلی",
    "art_direction": "مدال از روبه‌رو می‌چرخد؛ روبان باز می‌شود و پشت مدال به پنل دعوت تبدیل می‌شود.",
    "palette": {
      "base": "navy",
      "accent": "gold"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "مدال با روبان آویزان است",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "مدال یک دور می‌چرخد",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "روبان به دو طرف باز می‌شود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "پشت مدال به کارت گسترش می‌یابد",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با جزئیات مدال",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-033",
    "slug": "graduation-033-hall-of-light",
    "name": {
      "fa": "راهرو نور",
      "en": "Hall of Light"
    },
    "category": "graduation",
    "category_label": "فارغ‌التحصیلی",
    "art_direction": "درهای راهرو یکی‌یکی باز می‌شوند؛ دوربین به سمت انتها حرکت می‌کند و کارت در قاب آخر ظاهر می‌شود.",
    "palette": {
      "base": "white",
      "accent": "blue"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "راهرو در نمای مرکزی دیده می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "درها با ریتم باز می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "دوربین به جلو حرکت می‌کند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "قاب انتهایی به کارت تبدیل می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با نور طبیعی",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-034",
    "slug": "graduation-034-diploma-scroll",
    "name": {
      "fa": "کاغذ دیپلم",
      "en": "Diploma Scroll"
    },
    "category": "graduation",
    "category_label": "فارغ‌التحصیلی",
    "art_direction": "مهر دیپلم باز می‌شود؛ دو میله طومار از هم فاصله می‌گیرند و متن دعوت در کاغذ نمایان می‌شود.",
    "palette": {
      "base": "parchment",
      "accent": "burgundy"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "مهر روی طومار بسته دیده می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "مهر آزاد می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "میله‌ها به دو طرف می‌روند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "طومار کامل باز می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با کاغذ بافت‌دار",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-035",
    "slug": "graduation-035-cap-tassel",
    "name": {
      "fa": "کلاه و منگوله",
      "en": "Cap & Tassel"
    },
    "category": "graduation",
    "category_label": "فارغ‌التحصیلی",
    "art_direction": "منگوله دور کلاه حرکت می‌کند؛ کلاه بالا می‌رود و کارت زیر آن آشکار می‌شود.",
    "palette": {
      "base": "charcoal",
      "accent": "copper"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "کلاه روی سطح قرار دارد",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "منگوله یک دور می‌چرخد",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "کلاه بالا می‌رود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت زیر کلاه باز می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با کلاه در گوشه",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-036",
    "slug": "gala-036-royal-opera",
    "name": {
      "fa": "اپرای سلطنتی",
      "en": "Royal Opera"
    },
    "category": "gala",
    "category_label": "گالا",
    "art_direction": "پرده‌های سنگین اپرا جمع می‌شوند؛ نور صحنه روشن و کارت روی سکوی مرکزی نمایان می‌شود.",
    "palette": {
      "base": "oxblood",
      "accent": "gold"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "پرده بسته با چین‌های عمیق",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "پرده‌ها به طرفین جمع می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "نورافکن‌ها روی مرکز می‌افتند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "سکوی مرکزی بالا می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با صحنه اپرا",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-037",
    "slug": "gala-037-jewel-showcase",
    "name": {
      "fa": "ویترین جواهر",
      "en": "Jewel Showcase"
    },
    "category": "gala",
    "category_label": "گالا",
    "art_direction": "قفل ویترین باز می‌شود؛ شیشه به بالا می‌رود و کارت مانند قطعه جواهر روی پایه می‌چرخد.",
    "palette": {
      "base": "black",
      "accent": "diamond"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "قفل فلزی در نمای نزدیک",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "قفل با چرخش آزاد می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "شیشه ویترین بالا می‌رود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت روی پایه می‌چرخد و روبه‌رو می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با نور موزه‌ای",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-038",
    "slug": "gala-038-private-elevator",
    "name": {
      "fa": "آسانسور خصوصی",
      "en": "Private Elevator"
    },
    "category": "gala",
    "category_label": "گالا",
    "art_direction": "درهای آسانسور از مرکز باز می‌شوند؛ نور داخل کابین روشن و پنل دعوت روی دیواره نمایان می‌شود.",
    "palette": {
      "base": "graphite",
      "accent": "silver"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "نمای بسته درهای فلزی",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "خط نور بین درها روشن می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "درها به طرفین می‌لغزند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "پنل دعوت در عمق کابین ظاهر می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با فلز برس‌خورده",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-039",
    "slug": "gala-039-venetian-masquerade",
    "name": {
      "fa": "ماسک ونیزی",
      "en": "Venetian Masquerade"
    },
    "category": "gala",
    "category_label": "گالا",
    "art_direction": "ماسک روی محور می‌چرخد؛ روبان از پشت آن باز و کارت از سایه نمایان می‌شود.",
    "palette": {
      "base": "wine",
      "accent": "antique-gold"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "ماسک در نیم‌تاریکی دیده می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "ماسک به آرامی می‌چرخد",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "روبان از دو طرف باز می‌شود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از پشت ماسک بیرون می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با پر و طلاکوب",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-040",
    "slug": "gala-040-the-grand-table",
    "name": {
      "fa": "میز شام رسمی",
      "en": "The Grand Table"
    },
    "category": "gala",
    "category_label": "گالا",
    "art_direction": "دستمال سفره باز می‌شود؛ کارت منو از زیر آن بیرون می‌آید و به دعوت عمودی تبدیل می‌شود.",
    "palette": {
      "base": "cream",
      "accent": "bronze"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "چین دستمال در نمای بالا",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "دستمال با حرکت نرم باز می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "کارت منو از زیر آن بیرون می‌آید",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت عمودی می‌ایستد و باز می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با چیدمان میز",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-041",
    "slug": "traditional-041-khatam-door",
    "name": {
      "fa": "در خاتم",
      "en": "Khatam Door"
    },
    "category": "traditional",
    "category_label": "سنتی",
    "art_direction": "در خاتم‌کاری‌شده با دو لنگه باز می‌شود؛ نقش هندسی به حاشیه کارت تبدیل می‌شود.",
    "palette": {
      "base": "walnut",
      "accent": "turquoise"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "نقوش خاتم در نمای نزدیک",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "دو لنگه در باز می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "نقش‌ها به حاشیه منتقل می‌شوند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از عمق اتاق بیرون می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با قاب خاتم",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-042",
    "slug": "traditional-042-turquoise-iwan",
    "name": {
      "fa": "طاق فیروزه‌ای",
      "en": "Turquoise Iwan"
    },
    "category": "traditional",
    "category_label": "سنتی",
    "art_direction": "طاق کاشی‌کاری‌شده لایه‌لایه نمایان می‌شود؛ کتیبه بالا می‌رود و کارت زیر آن باز می‌شود.",
    "palette": {
      "base": "turquoise",
      "accent": "sand"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "سطح کاشی در نمای نزدیک",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "قاب طاق از پایین شکل می‌گیرد",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "کتیبه به بالا می‌رود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت در مرکز طاق باز می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با کاشی هندسی",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-043",
    "slug": "traditional-043-mashrabiya-lantern",
    "name": {
      "fa": "چراغ مشبک",
      "en": "Mashrabiya Lantern"
    },
    "category": "traditional",
    "category_label": "سنتی",
    "art_direction": "پنل‌های مشبک چراغ باز می‌شوند؛ نور گرم روی کاغذ می‌افتد و متن دعوت از سایه بیرون می‌آید.",
    "palette": {
      "base": "copper",
      "accent": "amber"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "چراغ خاموش در نمای نزدیک",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "پنل مشبک باز می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "چراغ روشن و سایه‌ها متحرک می‌شوند",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از داخل چراغ بیرون می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با نور گرم",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-044",
    "slug": "traditional-044-termeh-ceremony",
    "name": {
      "fa": "ترمه سلطنتی",
      "en": "Termeh Ceremony"
    },
    "category": "traditional",
    "category_label": "سنتی",
    "art_direction": "پارچه ترمه از چهار گوشه جمع می‌شود؛ نقش مرکزی به قاب دعوت تبدیل می‌شود.",
    "palette": {
      "base": "plum",
      "accent": "gold"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "پارچه ترمه کاملاً پهن است",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "چهار گوشه به مرکز جمع می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "نقش مرکزی برجسته می‌شود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت از زیر پارچه نمایان می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با حاشیه ترمه",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-045",
    "slug": "traditional-045-calligraphy-scroll",
    "name": {
      "fa": "طومار خوشنویسی",
      "en": "Calligraphy Scroll"
    },
    "category": "traditional",
    "category_label": "سنتی",
    "art_direction": "مرکب خوشنویسی به آرامی روی کاغذ شکل می‌گیرد؛ طومار باز و اطلاعات مراسم نمایان می‌شود.",
    "palette": {
      "base": "ink",
      "accent": "gold"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "کاغذ خالی با بافت دست‌ساز",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "مهر پایین کاغذ نمایان می‌شود",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "خط خوشنویسی نوشته می‌شود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "طومار افقی باز می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با تایپوگرافی خوشنویسی",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-046",
    "slug": "seasonal-046-winter-atrium",
    "name": {
      "fa": "باغ زمستانی",
      "en": "Winter Atrium"
    },
    "category": "seasonal",
    "category_label": "فصلی و خصوصی",
    "art_direction": "بلورهای یخ روی شیشه رشد می‌کنند؛ شیشه بخار می‌گیرد و با پاک‌شدن آن کارت نمایان می‌شود.",
    "palette": {
      "base": "ice",
      "accent": "silver"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "شیشه با بلور یخ پوشیده می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "بلورها به حاشیه حرکت می‌کنند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "بخار شیشه محو می‌شود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت پشت شیشه نمایان می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با برف نرم",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-047",
    "slug": "seasonal-047-mediterranean-postcard",
    "name": {
      "fa": "سفر مدیترانه‌ای",
      "en": "Mediterranean Postcard"
    },
    "category": "seasonal",
    "category_label": "فصلی و خصوصی",
    "art_direction": "کارت‌پستال از میان چند مهر پاسپورت بیرون می‌آید؛ نقشه تا می‌شود و مقصد به دعوت تبدیل می‌شود.",
    "palette": {
      "base": "azure",
      "accent": "terracotta"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "پاسپورت روی نقشه باز است",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "مهرهای سفر یکی‌یکی ظاهر می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "نقشه به سمت مقصد تا می‌شود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت‌پستال بیرون می‌آید و باز می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با حس سفر",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-048",
    "slug": "seasonal-048-midnight-garden",
    "name": {
      "fa": "جشن باغ شبانه",
      "en": "Midnight Garden"
    },
    "category": "seasonal",
    "category_label": "فصلی و خصوصی",
    "art_direction": "چراغ‌های باغ یکی‌یکی روشن می‌شوند؛ دروازه سبز باز و کارت در مسیر سنگ‌فرش ظاهر می‌شود.",
    "palette": {
      "base": "forest",
      "accent": "moonlight"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "باغ در تاریکی آرام دیده می‌شود",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "چراغ‌ها از نزدیک به دور روشن می‌شوند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "دروازه باغ باز می‌شود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت روی مسیر نمایان می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با نورهای بوکه",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-049",
    "slug": "private-party-049-gallery-opening",
    "name": {
      "fa": "گالری هنری",
      "en": "Gallery Opening"
    },
    "category": "private-party",
    "category_label": "فصلی و خصوصی",
    "art_direction": "قاب‌های هنری از دیوار کنار می‌روند؛ اثر مرکزی به کارت دعوت تبدیل می‌شود.",
    "palette": {
      "base": "white",
      "accent": "black"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "دیوار گالری با قاب‌های متعدد",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "قاب‌ها به طرفین می‌لغزند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "اثر مرکزی بزرگ می‌شود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "اثر به کارت اطلاعاتی تبدیل می‌شود",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با فضای گالری",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  },
  {
    "id": "pro-showcase-050",
    "slug": "private-party-050-vip-ticket-reveal",
    "name": {
      "fa": "بلیت VIP",
      "en": "VIP Ticket Reveal"
    },
    "category": "private-party",
    "category_label": "فصلی و خصوصی",
    "art_direction": "هولوگرام روی بلیت حرکت می‌کند؛ بخش پرفراژ جدا می‌شود و کارت VIP از زیر آن بیرون می‌آید.",
    "palette": {
      "base": "black",
      "accent": "neon-lime"
    },
    "opening_sequence": [
      {
        "step": 1,
        "scene": "establishing-shot",
        "title": "نمای معرفی",
        "description": "بلیت بسته با هولوگرام متحرک",
        "duration_ms": 900
      },
      {
        "step": 2,
        "scene": "mechanism-release",
        "title": "شروع مکانیزم",
        "description": "نور هولوگرام اسکن می‌کند",
        "duration_ms": 1100
      },
      {
        "step": 3,
        "scene": "layer-reveal",
        "title": "بازشدن لایه‌ها",
        "description": "لبه پرفراژ جدا می‌شود",
        "duration_ms": 1200
      },
      {
        "step": 4,
        "scene": "card-emergence",
        "title": "ورود کارت",
        "description": "کارت VIP از زیر بلیت بیرون می‌آید",
        "duration_ms": 1300
      },
      {
        "step": 5,
        "scene": "final-composition",
        "title": "نمای نهایی",
        "description": "نمای نهایی با کد و جزئیات رویداد",
        "duration_ms": 1500
      }
    ],
    "editor_fields": [
      "host_names",
      "guest_name",
      "event_title",
      "date",
      "time",
      "venue",
      "address",
      "message",
      "cover_image"
    ],
    "interaction": {
      "desktop": [
        "click",
        "drag"
      ],
      "mobile": [
        "tap",
        "swipe"
      ],
      "skip_available": true,
      "replay_available": true
    },
    "accessibility": {
      "reduced_motion": "crossfade",
      "audio_default": "off",
      "keyboard_navigation": true
    },
    "rendering": {
      "aspect_ratio": "9:16",
      "mobile_first": true,
      "rtl_ready": true,
      "scene_based": true
    }
  }
];
